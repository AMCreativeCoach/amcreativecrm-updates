// LinkedIn event invite list — "select every connection".
//
// LinkedIn's invite modal gives you a checkbox per connection and no way to
// tick them all, which makes inviting a few hundred people a few hundred
// clicks. This ticks them.
//
// **It never clicks Invite.** Same boundary as the rest of this extension:
// we prepare, the human sends. Selecting is reversible and visible — the
// modal shows exactly who is ticked and a running count — so the decision to
// actually send stays a deliberate act. See feedback_linkedin_send.md.
//
// ## Where the list actually is
//
// Inside an OPEN SHADOW ROOT on `#interop-outlet` (LinkedIn's
// `data-testid="interop-shadowdom"` wrapper), which LinkedIn introduced around
// March 2026. `document.querySelectorAll` does not look inside shadow roots,
// which is why four earlier versions of this script found zero checkboxes
// while fifty sat on screen. It is NOT an iframe — adding `allFrames` would
// only reach LinkedIn's hidden /preload/ iframe, which holds decoy copies.
//
// Verified against a working August 2026 script (uldiskk/pybots,
// LinkedIn_invite_to_page_or_event.py), which uses exactly:
//   #interop-outlet -> .shadowRoot -> .invitee-picker__result-item
//   -> input[type="checkbox"] -> .click() -> verify .checked
//   load more via .scaffold-finite-scroll__load-button, skip rows reading "Invited".

(() => {
  "use strict";

  const ext = globalThis.browser || globalThis.chrome;

  // Keyed on the extension version, not a plain flag: a boolean survived an
  // extension reload on the page and made the new version bow out in favour of
  // a dead one.
  const version = (() => {
    try { return ext.runtime.getManifest().version; } catch (_) { return "unknown"; }
  })();
  if (globalThis.__amcrmInviteSelectorVersion === version) return;
  globalThis.__amcrmInviteSelectorVersion = version;

  /// Backstop against a runaway loop. LinkedIn's own limit is 1,000
  /// invitations per week across all events, and it disables rows past it, so
  /// in practice LinkedIn stops this long before the cap does.
  const MAX_SELECTIONS = 1000;
  const MAX_ROUNDS = 150;
  const SETTLE_MS = 900;
  /// Rounds with no new rows before the list counts as fully loaded.
  const STABLE_ROUNDS = 3;

  const HOST_SELECTOR = '#interop-outlet, [data-testid="interop-shadowdom"]';
  /// Primary row selector is the verified one. The typeahead row is a
  /// single-source fallback kept only in case LinkedIn swaps markup.
  const ROW_SELECTOR = '.invitee-picker__result-item, li.artdeco-typeahead__result';
  const LOAD_MORE_SELECTOR = '.scaffold-finite-scroll__load-button';

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const nextFrame = () => new Promise(r => requestAnimationFrame(() => setTimeout(r, 0)));

  // ---------------------------------------------------------------
  // Shadow DOM
  // ---------------------------------------------------------------

  /// A shadow root, open or closed. Open roots are readable directly. Closed
  /// ones need `dom.openOrClosedShadowRoot`, which Safari added in 26.0; on
  /// older Safari a closed root is unreachable from an extension. The evidence
  /// is that LinkedIn's root is currently open.
  function shadowOf(el) {
    if (el.shadowRoot) return el.shadowRoot;
    try { return ext?.dom?.openOrClosedShadowRoot?.(el) || null; }
    catch (_) { return null; }
  }

  /// Every shadow root reachable beneath `start`, including `start` itself.
  function rootsUnder(start) {
    const out = [start];
    for (let i = 0; i < out.length; i++) {
      for (const el of out[i].querySelectorAll("*")) {
        const sr = shadowOf(el);
        if (sr) out.push(sr);
      }
    }
    return out;
  }

  /// Query across the interop shadow tree first, then the light DOM.
  function deepAll(selector) {
    const host = document.querySelector(HOST_SELECTOR);
    const start = (host && shadowOf(host)) || document;
    const roots = rootsUnder(start);
    if (start !== document) roots.push(document);
    return roots.flatMap(r => Array.from(r.querySelectorAll(selector)));
  }

  /// The invite dialog: whichever dialog holds the most checkboxes. Scoping to
  /// it keeps us off the filter dropdowns, which carry checkboxes of their own
  /// in the same shadow root — a bare "every checkbox" selector would tick
  /// "Current company" filters too.
  function inviteDialog() {
    return deepAll('[role="dialog"], [aria-modal="true"]')
      .map(d => [d, d.querySelectorAll('input[type="checkbox"]').length])
      .sort((a, b) => b[1] - a[1])[0]?.[0] || null;
  }

  function inviteeRows(dialog) {
    let rows = Array.from(dialog.querySelectorAll(ROW_SELECTOR));
    if (!rows.length) {
      // Last resort if both row classes change: list items holding exactly one
      // checkbox. Filter options are rarely shaped like that.
      rows = Array.from(dialog.querySelectorAll("li"))
        .filter(li => li.querySelectorAll('input[type="checkbox"]').length === 1);
    }
    return rows
      .map(row => ({ row, cb: row.querySelector('input[type="checkbox"], [role="checkbox"]') }))
      .filter(x => x.cb);
  }

  const isChecked = cb =>
    cb.tagName === "INPUT" ? cb.checked : cb.getAttribute("aria-checked") === "true";

  /// Anything LinkedIn is refusing. "Invited" is English-only and comes from
  /// one source, so it sits alongside the attribute checks rather than
  /// replacing them.
  const isBlocked = ({ row, cb }) =>
    cb.disabled ||
    cb.getAttribute("aria-disabled") === "true" ||
    row.getAttribute("aria-disabled") === "true" ||
    /\bInvited\b/.test(row.innerText || "");

  // ---------------------------------------------------------------
  // Selecting
  // ---------------------------------------------------------------

  /// Click the input itself, then CHECK. Clicking dispatches click -> input ->
  /// change, which is composed and reaches React's listener at the root.
  ///
  /// Only falls back to the label if the first click demonstrably did nothing,
  /// and only after a frame. The previous version clicked the label and then
  /// the row whenever the state had not flipped *yet* — if React updated a tick
  /// a moment late, that second click unticked it again.
  async function tick(cb) {
    if (isChecked(cb)) return false;
    cb.click();
    await nextFrame();
    if (isChecked(cb)) return true;
    // label[for] lives in the same shadow root as the input, not in document.
    const root = cb.getRootNode();
    const label = cb.closest("label") ||
      (cb.id && root.querySelector(`label[for="${CSS.escape(cb.id)}"]`));
    if (label) {
      label.click();
      await nextFrame();
    }
    return isChecked(cb);
  }

  /// LinkedIn's own "N selected" figure. Compared with our count, it proves
  /// the ticks registered in LinkedIn's state and not just on screen.
  function linkedInSelectedCount(dialog) {
    const m = (dialog.innerText || "").match(/(\d[\d,]*)\s+selected/i);
    return m ? Number(m[1].replace(/,/g, "")) : null;
  }

  /// A scripted scrollTop does not reliably trigger LinkedIn's loader, so the
  /// load-more button comes first and scrolling the last row into view is the
  /// fallback.
  async function loadMore(dialog) {
    const btn = dialog.querySelector(LOAD_MORE_SELECTOR) ||
      deepAll(LOAD_MORE_SELECTOR)[0];
    if (btn && !btn.disabled) {
      btn.click();
      return;
    }
    inviteeRows(dialog).at(-1)?.row.scrollIntoView({ block: "end" });
  }

  async function selectAll() {
    const dialog = inviteDialog();
    if (!dialog) return { ok: false, error: "no-dialog", diagnostics: diagnose() };

    let selected = 0;
    let stable = 0;
    let lastRows = -1;

    for (let round = 0; round < MAX_ROUNDS && selected < MAX_SELECTIONS; round++) {
      for (const r of inviteeRows(dialog)) {
        if (selected >= MAX_SELECTIONS) break;
        if (isChecked(r.cb) || isBlocked(r)) continue;
        if (await tick(r.cb)) selected++;
      }
      const n = inviteeRows(dialog).length;
      stable = n === lastRows ? stable + 1 : 0;
      lastRows = n;
      if (stable >= STABLE_ROUNDS) break;
      await loadMore(dialog);
      await sleep(SETTLE_MS);
    }

    const rows = inviteeRows(dialog);
    return {
      ok: true,
      selected,
      rows: rows.length,
      blocked: rows.filter(isBlocked).length,
      linkedInCounter: linkedInSelectedCount(dialog),
      hitCap: selected >= MAX_SELECTIONS,
    };
  }

  // ---------------------------------------------------------------
  // Diagnostics — shown in the popup, not buried in a console
  // ---------------------------------------------------------------

  function diagnose() {
    const host = document.querySelector(HOST_SELECTOR);
    return {
      url: location.href,
      interopHost: !!host,
      interopShadowOpen: !!host?.shadowRoot,
      closedRootApi: !!ext?.dom?.openOrClosedShadowRoot,
      lightCheckboxes: document.querySelectorAll('input[type="checkbox"]').length,
      deepCheckboxes: deepAll('input[type="checkbox"]').length,
      deepRows: deepAll(ROW_SELECTOR).length,
      deepDialogs: deepAll('[role="dialog"], [aria-modal="true"]').length,
    };
  }

  ext.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message) return;
    if (message.type === "select-all-invites") {
      selectAll()
        .then(sendResponse)
        .catch(err => sendResponse({
          ok: false,
          error: String((err && err.message) || err),
          diagnostics: diagnose(),
        }));
      return true;
    }
    if (message.type === "diagnose-invites") {
      sendResponse({ ok: true, diagnostics: diagnose() });
      return true;
    }
  });
})();
