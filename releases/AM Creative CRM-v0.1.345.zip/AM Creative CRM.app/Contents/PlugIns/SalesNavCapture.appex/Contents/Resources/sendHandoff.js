// Sales Nav send-followup handoff — EARLY capture (document_start).
//
// The host app opens `…/sales/lead/<URN>?…&amcrm_send_text=<base64 JSON>` to
// hand a drafted InMail to the extension. Sales Navigator's SPA router rewrites
// the URL on load (it swaps in its own `?_ntb=` tracking param and drops
// unknown query params like ours) BEFORE the main content.js runs at
// document_idle — so by the time SEND_FOLLOWUP.maybeBootstrap reads
// `location.search`, the handoff is already gone and the fill never starts
// (the message only lands on the clipboard fallback).
//
// This script runs at document_start — before LinkedIn's router executes — so
// it still sees the original URL. It grabs the handoff, stashes it in extension
// storage (with a timestamp), and strips it from the visible URL. The main
// content script's SEND_FOLLOWUP module then recovers it from storage, consumes
// it once, and only if it's fresh — preserving the "fires only on the app's
// open, never a later visit, never re-fires" guarantee. It never clicks Send.
(function () {
  try {
    var params = new URLSearchParams(location.search);
    var encoded = params.get("amcrm_send_text");
    if (!encoded) return;

    // Strip it from the visible URL immediately so a manual reload can't
    // resurface it, mirroring the main module's history.replaceState.
    params.delete("amcrm_send_text");
    var qs = params.toString();
    history.replaceState({}, "", location.pathname + (qs ? "?" + qs : "") + location.hash);

    // Persist so the document_idle fill can recover it after the SPA rewrite.
    // `Date.now()` stamps freshness; the consumer ignores anything older than a
    // couple of minutes.
    browser.storage.local.set({
      amcrm_send_text: encoded,
      amcrm_send_text_ts: Date.now()
    });
  } catch (err) {
    // Best effort. If the param happens to survive to document_idle, the main
    // module's URL read still works.
    console.error("[AMCRM send-followup early] capture failed:", err);
  }
})();
