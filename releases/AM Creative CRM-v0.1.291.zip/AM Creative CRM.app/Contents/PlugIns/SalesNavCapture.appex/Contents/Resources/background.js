// Background service worker for the Sales Nav Capture extension.
//
// The content script can't call `browser.tabs.captureVisibleTab`
// directly — that API is restricted to background / popup contexts
// — so the script delegates each viewport-sized capture through
// here. The content script does the scrolling + canvas-stitch
// itself; this worker is a tiny postbox that pulls one PNG dataURL
// per request and hands it back.
//
// Used by:
//   - The popup's "Capture this profile" button (one capture pass
//     per click)
//   - The PDF auto-walker when the user has enabled the
//     "screenshots instead of PDFs" toggle, in which case the
//     walker calls scroll-and-stitch on every queued lead instead
//     of clicking LinkedIn's Save-to-PDF menu item.
//
// **Why a worker at all.** Pre-v0.1.82 this extension shipped
// without any background script — the popup did all the work via
// the `amcreativecrm://import` URL scheme. captureVisibleTab needs
// a privileged context, so we add the smallest possible one here.
// Stays stateless; no caching, no message routing beyond the
// single capture handler.

browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== "captureVisibleTab") return;
  // captureVisibleTab returns a Promise<dataURL>. The async
  // pattern needed for `onMessage` is to call sendResponse() from
  // a .then() and return `true` from the listener so the messaging
  // channel stays open until we resolve.
  browser.tabs
    .captureVisibleTab(null, { format: "png" })
    .then(dataURL => {
      sendResponse({ ok: true, dataURL });
    })
    .catch(err => {
      console.error("[AMCRM background] captureVisibleTab failed:", err);
      sendResponse({ ok: false, error: String(err && err.message ? err.message : err) });
    });
  return true;
});
