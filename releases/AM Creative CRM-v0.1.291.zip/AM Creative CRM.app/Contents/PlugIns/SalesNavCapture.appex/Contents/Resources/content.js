// Sales Navigator lead-card capture script.
//
// Runs on every linkedin.com/sales/* page. Injects a small
// "Capture to CRM" toggle into each lead-result card so the user
// can mark individual rows for import. Selections live in
// browser.storage.local and persist across pages of the same
// search / list — the toolbar popup reads them and ships the
// final batch to the host CRM via the amcreativecrm:// URL scheme.
//
// **Bounded traversal only.** The script never scrolls, paginates,
// or loads additional pages. On Sales Navigator it touches nothing
// — it only injects per-card pills next to results the user has
// already loaded. On the Service Marketplace Provider → Requests
// page it does one user-initiated extra step: when the user clicks
// "Capture all visible" or a per-card pill, the script sequentially
// clicks each list `<li>` to populate the right-pane detail view,
// scrapes the request body + profile URL, then moves to the next.
// That click traversal is the only way to capture the questionnaire
// answers — the list rows themselves only show name + service.
//
// **Selectors are intentionally defensive.** Sales Nav's exact
// class names rotate every few months — we try known selectors
// first, then fall back to walking up from any profile link to
// the nearest card-shaped container. Open Safari → Develop →
// Show Web Inspector → Console and watch for `[AMCRM]` messages
// to diagnose injection / selection issues.

(function () {
  "use strict";

  const LOG_PREFIX = "[AMCRM]";
  function log(...args) { console.log(LOG_PREFIX, ...args); }
  function warn(...args) { console.warn(LOG_PREFIX, ...args); }

  log("Content script loaded on:", location.href);

  // Surface detection — drives selector pool + per-card field
  // extraction + the `origin` tag attached to each capture so
  // the host CRM can route Sales Nav vs Marketplace leads
  // correctly downstream.
  //
  // `walker` is a third surface — the script enters that mode when
  // the host app bootstraps a queue via `?amcrm_queue=<b64>` on the
  // first item's URL, or when a stored queue is mid-walk. In walker
  // mode the per-card capture UI is entirely suppressed: the page
  // belongs to the auto-downloader, not to manual selection.
  const onProfilePage = location.pathname.startsWith("/in/");
  const onSalesLeadPage = location.pathname.startsWith("/sales/lead/");
  const SURFACE = location.href.includes("/service-marketplace/")
    ? "marketplace"
    : onProfilePage
      ? "profile"
      : "salesNav";
  log(`Surface detected: ${SURFACE}`);

  // =========================================================
  // PDF auto-walker
  // =========================================================
  //
  // Drives an end-to-end LinkedIn-profile-to-PDF download loop
  // across a queue of leads. The macOS app launches it by opening
  // Safari at the first lead's profile URL with a base64-encoded
  // queue tacked on as `?amcrm_queue=<b64>`. Each navigation
  // reloads this content script; the walker reads queue state out
  // of `browser.storage.local`, figures out what step it should
  // run next, and either: (a) clicks `More → Save to PDF` on a
  // matching `/in/...` page, (b) follows the public-profile link
  // out of a `/sales/lead/...` page when the direct URL wasn't
  // captured, or (c) navigates to the next queued lead's URL after
  // a 2–4 minute randomized delay. State is fully persisted
  // between navigations so the loop survives reloads.

  const WALKER = (() => {
    const STORAGE_QUEUE = "amcrm_walker_queue";
    const STORAGE_CURSOR = "amcrm_walker_cursor";
    const STORAGE_NEXT_AT = "amcrm_walker_next_at";
    const STORAGE_RESULTS = "amcrm_walker_results";
    const STORAGE_STATUS_MSG = "amcrm_walker_status";
    /// Explicit "the user just started a bulk download" flag.
    /// Set ONLY by:
    ///   - popup.js when the user clicks Download in the popup
    ///   - this script's `maybeBootstrap` when an `?amcrm_queue=`
    ///     URL fires (the macOS launcher's path)
    ///
    /// Cleared by `clearQueue` (queue finished or send-followup
    /// took over). Without this flag set, tick() bails immediately
    /// — no matter what's in storage, the walker stays silent on
    /// random LinkedIn navigation, Send Follow-up flows, or any
    /// other page load that isn't an explicitly-started bulk run.
    /// This is the final fix for "Send Follow-up keeps bouncing me
    /// to a different lead" — the walker can't navigate if it
    /// isn't running.
    const STORAGE_SESSION_ACTIVE = "amcrm_walker_session_active";
    /// `"pdf"` (default) or `"screenshot"` — set at queue install
    /// time. When `"screenshot"`, the walker calls the
    /// scroll-stitch SCREENSHOT module instead of LinkedIn's
    /// Save-to-PDF menu. Useful when LinkedIn's PDF generation
    /// is rate-limited (their server-side caps kick in after a
    /// day of heavy use) — screenshots are entirely local and
    /// have no per-day quota.
    const STORAGE_CAPTURE_MODE = "amcrm_walker_capture_mode";
    /// Path (no host / query) we just successfully saved a PDF
    /// from. The URN-exception in `currentPageMatchesTarget` uses
    /// this to distinguish "we've navigated to /in/{URN} and
    /// LinkedIn redirected to /in/{slug}" from "we're still
    /// sitting on the PREVIOUS lead's profile because the
    /// inter-item nav timer hasn't fired yet." Without this check
    /// a URN-shaped target would accept the previous lead's page
    /// as a match and the walker would re-save the same PDF on
    /// every tick re-fire (visibility change, stale timer) until
    /// the navigation eventually moved us off.
    const STORAGE_LAST_SAVED_PATH = "amcrm_walker_last_saved_path";

    // Randomized inter-item delay, picked fresh after each save.
    // Adam asked for "a few minutes" between downloads — the range
    // below averages roughly three minutes so a 50-lead queue takes
    // ~2.5h, low enough to keep LinkedIn from flagging the cadence
    // as scripted but human-paced enough that he can leave it
    // running in the background.
    const DELAY_MIN_MS = 120_000;
    const DELAY_MAX_MS = 240_000;

    // Selector pools — defensive against LinkedIn's UI rotations.
    // We try aria-label patterns first (most durable) and fall
    // back to known class names. Order matters: the first
    // selector that matches wins, so the most specific patterns
    // come first.
    //
    // **Why so many.** LinkedIn rotates its action-bar markup
    // every few months and personalizes the aria-label
    // ("More actions for Sarah Chen", "More options for
    // {Name}", etc.) so an exact-match selector ages fast. The
    // pool below covers every variant we've seen plus a generic
    // catch-all that walks `main` for any overflow trigger near
    // the profile header. If even the catch-all misses, we run
    // a diagnostic dump (`debugDumpButtons`) so the failing run
    // tells us exactly what selectors were on the page.
    const MORE_BUTTON_SELECTORS = [
      // Personalized aria-label patterns LinkedIn ships in 2025.
      'button[aria-label^="More actions" i]',
      'button[aria-label*="More actions for" i]',
      'button[aria-label*="More options for" i]',
      'button[aria-label*="More profile actions" i]',
      // Generic "More" inside the profile main column, excluding
      // the Message / Follow / Connect siblings that would
      // otherwise match a loose `*="More"` filter.
      'main button[aria-label*="More" i]:not([aria-label*="message" i]):not([aria-label*="follow" i]):not([aria-label*="connect" i])',
      'main button[aria-label*="more options" i]',
      // Profile-specific overflow class names that have shipped
      // historically. The exact class drifts; keep multiple.
      "button.pv-s-profile-actions__overflow-toggle",
      "button.profile-actions__overflow-btn",
      ".pv-top-card__action-bar button.artdeco-dropdown__trigger",
      ".pv-top-card-v2-ctas button.artdeco-dropdown__trigger",
      ".pv-top-card-v3-ctas button.artdeco-dropdown__trigger",
      // Last-ditch generic: any overflow dropdown in the main
      // column that isn't the messaging composer. We sift the
      // returned set in `findMoreButton` to drop hidden ones and
      // pick the one closest to the profile header.
      'main section button.artdeco-dropdown__trigger',
      'main button[aria-haspopup="true"]:not([aria-label*="message" i]):not([aria-label*="follow" i]):not([aria-label*="connect" i])'
    ];
    const SAVE_TO_PDF_LABEL_PATTERN = /save to pdf/i;
    const PUBLIC_PROFILE_LINK_SELECTORS = [
      // Most reliable: any anchor whose href IS a public profile.
      'a[href^="https://www.linkedin.com/in/"]',
      'a[href^="/in/"]',
      // Sales Nav v3 sometimes wraps the public link in a relative
      // href without the leading slash on the anchor — match those
      // by `*=` fallback while still requiring `/in/` substring so
      // we don't pick up `/sales/lead/` URLs.
      'a[href*="linkedin.com/in/"]',
      'a[href*="/in/"][role="link"]',
      // Some Sales Nav layouts expose the public link inside an
      // entity icon button or a "View LinkedIn profile" wrapper.
      '[data-anonymize="person-name"] a[href*="/in/"]',
      '[data-test-public-profile-link] a',
      'a[data-test-public-profile-link]'
    ];

    let overlayEl = null;
    let countdownTimer = null;
    let navigationTimer = null;
    let inFlight = false;

    /// Reads + caches the queue / cursor / results / next-action
    /// timestamps from storage. Returns a plain object the rest of
    /// the walker reasons over; never throws (missing keys return
    /// the empty / zero defaults).
    async function readState() {
      const raw = await browser.storage.local.get([
        STORAGE_QUEUE,
        STORAGE_CURSOR,
        STORAGE_NEXT_AT,
        STORAGE_RESULTS,
        STORAGE_STATUS_MSG,
        STORAGE_LAST_SAVED_PATH,
        STORAGE_CAPTURE_MODE
      ]);
      return {
        queue: Array.isArray(raw[STORAGE_QUEUE]) ? raw[STORAGE_QUEUE] : [],
        cursor: typeof raw[STORAGE_CURSOR] === "number" ? raw[STORAGE_CURSOR] : 0,
        nextAt: typeof raw[STORAGE_NEXT_AT] === "number" ? raw[STORAGE_NEXT_AT] : 0,
        results: Array.isArray(raw[STORAGE_RESULTS]) ? raw[STORAGE_RESULTS] : [],
        status: raw[STORAGE_STATUS_MSG] || "",
        lastSavedPath: raw[STORAGE_LAST_SAVED_PATH] || "",
        captureMode: raw[STORAGE_CAPTURE_MODE] === "screenshot" ? "screenshot" : "pdf"
      };
    }

    async function writeState(patch) {
      // The storage API rejects undefined values; filter them so
      // callers can clear a key by passing { foo: null }.
      const out = {};
      for (const [k, v] of Object.entries(patch)) {
        if (v === undefined) continue;
        out[k] = v;
      }
      await browser.storage.local.set(out);
    }

    async function clearQueue() {
      await browser.storage.local.remove([
        STORAGE_QUEUE,
        STORAGE_CURSOR,
        STORAGE_NEXT_AT,
        STORAGE_STATUS_MSG,
        STORAGE_LAST_SAVED_PATH,
        STORAGE_CAPTURE_MODE,
        // Drop the session flag so subsequent ticks no-op
        // until the popup or a URL bootstrap explicitly
        // starts a new run. Critical: prevents the stale
        // walker from waking on visibility-change ticks.
        STORAGE_SESSION_ACTIVE
      ]);
      // Leave STORAGE_RESULTS intact so the user can read the
      // completion overlay (rendered next time `tick()` runs and
      // sees no queue) — it will get cleaned up next bootstrap.
    }

    /// Decodes `?amcrm_queue=<b64>` if present, writes the payload
    /// into storage, and strips the param so a manual refresh
    /// doesn't double-bootstrap. Returns true when a queue was
    /// installed this tick (so the caller knows to fall through
    /// directly into the first action rather than waiting for the
    /// next page reload).
    async function maybeBootstrap() {
      const url = new URL(location.href);
      const encoded = url.searchParams.get("amcrm_queue");
      if (!encoded) return false;
      try {
        const json = decodeURIComponent(escape(atob(encoded)));
        const payload = JSON.parse(json);
        if (!Array.isArray(payload.items) || payload.items.length === 0) {
          warn("Walker bootstrap: empty queue, ignoring.");
          return false;
        }
        // macOS-launched queues now carry a capture mode in the
        // payload (`payload.captureMode === "screenshot" | "pdf"`).
        // Default to PDF when the field is missing for backward
        // compat with older app builds that didn't set it.
        const captureMode = payload.captureMode === "screenshot" ? "screenshot" : "pdf";
        await writeState({
          [STORAGE_QUEUE]: payload.items,
          [STORAGE_CURSOR]: 0,
          [STORAGE_NEXT_AT]: 0,
          [STORAGE_RESULTS]: [],
          [STORAGE_STATUS_MSG]: `Queue installed: ${payload.items.length} lead(s).`,
          [STORAGE_LAST_SAVED_PATH]: "",
          [STORAGE_CAPTURE_MODE]: captureMode,
          // Light the session flag so tick() will actually run
          // for this URL-bootstrapped queue. Cleared when the
          // queue finishes via clearQueue.
          [STORAGE_SESSION_ACTIVE]: true
        });
        // Strip the query param so refreshing doesn't re-install
        // an older copy of the queue.
        url.searchParams.delete("amcrm_queue");
        history.replaceState({}, "", url.toString());
        log(`Walker bootstrapped with ${payload.items.length} item(s).`);
        return true;
      } catch (err) {
        console.error("[AMCRM walker] bootstrap failed:", err);
        return false;
      }
    }

    /// True when there's an active (non-empty, non-finished)
    /// queue. The script's main flow uses this to decide whether
    /// to skip the per-card capture init on Sales Nav surfaces
    /// (don't inject Capture buttons on top of a page the walker
    /// is about to navigate away from).
    async function isActive() {
      const { queue, cursor } = await readState();
      return queue.length > 0 && cursor < queue.length;
    }

    /// Pretty time string for the countdown overlay.
    function fmtCountdown(ms) {
      if (ms <= 0) return "0:00";
      const total = Math.round(ms / 1000);
      const m = Math.floor(total / 60);
      const s = total % 60;
      return `${m}:${String(s).padStart(2, "0")}`;
    }

    /// Renders / updates the floating progress overlay. Lives in
    /// the corner so the user can leave the tab in the background
    /// and glance at it during a long run.
    async function renderOverlay(force) {
      const state = await readState();
      const { queue, cursor, nextAt, status } = state;
      const total = queue.length;
      if (total === 0) {
        if (overlayEl) overlayEl.remove();
        overlayEl = null;
        if (countdownTimer) { clearInterval(countdownTimer); countdownTimer = null; }
        return;
      }
      if (!overlayEl || force) {
        if (overlayEl) overlayEl.remove();
        overlayEl = document.createElement("div");
        overlayEl.id = "amcrm-walker-overlay";
        Object.assign(overlayEl.style, {
          position: "fixed",
          right: "18px",
          bottom: "18px",
          zIndex: "2147483647",
          background: "rgba(15,23,42,0.95)",
          color: "#fff",
          padding: "12px 14px",
          borderRadius: "10px",
          boxShadow: "0 10px 30px rgba(0,0,0,0.35)",
          fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
          fontSize: "13px",
          lineHeight: "1.4",
          minWidth: "260px",
          maxWidth: "320px"
        });
        overlayEl.innerHTML = `
          <div style="display:flex; align-items:center; gap:8px; margin-bottom:6px;">
            <div style="font-weight:600;">AM Creative CRM auto-download</div>
            <div style="flex:1;"></div>
            <button id="amcrm-walker-next"
              style="background:rgba(59,130,246,0.85);border:1px solid rgba(59,130,246,1);color:#fff;font-size:11px;padding:2px 8px;border-radius:6px;cursor:pointer;"
              title="Skip the wait and advance to the next lead now">
              Next now
            </button>
            <button id="amcrm-walker-cancel"
              style="background:transparent;border:1px solid rgba(255,255,255,0.4);color:#fff;font-size:11px;padding:2px 8px;border-radius:6px;cursor:pointer;">
              Cancel
            </button>
          </div>
          <div id="amcrm-walker-progress" style="margin-bottom:4px;"></div>
          <div id="amcrm-walker-status" style="opacity:0.8; font-size:12px;"></div>
          <div id="amcrm-walker-countdown" style="opacity:0.7; font-size:11px; margin-top:4px;"></div>
        `;
        document.body.appendChild(overlayEl);
        const cancelBtn = overlayEl.querySelector("#amcrm-walker-cancel");
        cancelBtn.addEventListener("click", async () => {
          if (!confirm("Stop the auto-download queue?")) return;
          await clearQueue();
          if (navigationTimer) { clearTimeout(navigationTimer); navigationTimer = null; }
          await renderOverlay(true);
        });
        // **Next now** — bypasses the inter-item delay. Useful
        // when the user can see the previous PDF already
        // downloaded and doesn't want to wait the full 2–4 min,
        // OR when Safari's background-tab throttling stalled
        // the auto-navigation timer. Routes through
        // `advanceNow()` so the same recovery / cursor-vs-page
        // logic in tick() applies.
        const nextBtn = overlayEl.querySelector("#amcrm-walker-next");
        nextBtn.addEventListener("click", async () => {
          await advanceNow();
        });
      }
      const current = queue[cursor];
      const progress = overlayEl.querySelector("#amcrm-walker-progress");
      const statusEl = overlayEl.querySelector("#amcrm-walker-status");
      const countdownEl = overlayEl.querySelector("#amcrm-walker-countdown");
      if (cursor >= total) {
        progress.textContent = `All ${total} leads complete.`;
        statusEl.textContent = status || "Ready to close.";
        countdownEl.textContent = "";
      } else {
        progress.textContent = `Lead ${cursor + 1} of ${total} — ${current?.name || "(unnamed)"}`;
        statusEl.textContent = status || "";
        const remaining = nextAt - Date.now();
        if (remaining > 0) {
          countdownEl.textContent = `Next download in ${fmtCountdown(remaining)}`;
        } else {
          countdownEl.textContent = "";
        }
      }
      // Keep the countdown ticking once a second so the overlay
      // feels live during the long inter-item sleeps.
      if (!countdownTimer) {
        countdownTimer = setInterval(async () => {
          const fresh = await readState();
          if (!fresh.queue.length) {
            clearInterval(countdownTimer);
            countdownTimer = null;
            return;
          }
          const remaining = fresh.nextAt - Date.now();
          if (countdownEl) {
            countdownEl.textContent = remaining > 0
              ? `Next download in ${fmtCountdown(remaining)}`
              : "";
          }
        }, 1000);
      }
    }

    /// Returns the first usable target URL for the queue item.
    /// Preference order:
    ///   1. `item.publicURL` when the popup / launcher captured a
    ///      public `/in/{slug}` URL outright.
    ///   2. **URN-derived `/in/{URN}`** when only a Sales Nav URL
    ///      is on file — LinkedIn redirects URN-based `/in/`
    ///      paths to the canonical public profile server-side,
    ///      so the walker lands on a real profile page where
    ///      Save-to-PDF works. This skips the "Unlock full
    ///      profile" interstitial that the Sales Nav lead page
    ///      shows for out-of-network leads (where the
    ///      selector-based redirect couldn't escape).
    ///   3. The raw Sales Nav URL as a last-resort fallback,
    ///      letting the walker's anchor-scrape path handle it.
    function targetURL(item) {
      if (item.publicURL) return item.publicURL;
      const urn = extractSalesNavURN(item.salesNavURL || "");
      if (urn) return `https://www.linkedin.com/in/${urn}`;
      return item.salesNavURL || "";
    }

    /// Extracts the URN out of a Sales Nav lead URL. See
    /// `popup.js`'s `extractSalesNavURN` for the same regex —
    /// duplicated here because the walker is its own
    /// IIFE-scoped module and pulling popup.js into the content
    /// script bundle isn't worth the build wiring.
    function extractSalesNavURN(url) {
      if (!url) return null;
      const m = String(url).match(/\/sales\/lead\/([A-Za-z0-9_-]+)/i);
      return m ? m[1] : null;
    }

    /// True when `slug` looks like a LinkedIn URN (encrypted
    /// member ID) rather than a human-readable profile slug.
    /// URNs are typically 30+ chars of base64-ish alphabet
    /// starting with `AC` (e.g. `ACoAAA…`, `ACwAAA…`); slugs
    /// like `sarah-chen-12345` use lowercase + hyphens and run
    /// shorter. When the walker navigates to `/in/{URN}` and
    /// LinkedIn redirects to `/in/{slug}`, the slug-mismatch
    /// guard would otherwise flag the navigation as a redirect
    /// to "the wrong person" — this helper lets us skip the
    /// guard for known URN→slug redirects.
    function looksLikeURN(slug) {
      if (!slug) return false;
      const s = String(slug);
      return s.length > 25 && /^[A-Za-z0-9_-]+$/.test(s) && /^AC/i.test(s);
    }

    /// Picks an arbitrary delay between DELAY_MIN_MS and
    /// DELAY_MAX_MS. Slight jitter so two queues kicked off in
    /// quick succession don't request profiles at identical
    /// intervals.
    function pickDelay() {
      const span = DELAY_MAX_MS - DELAY_MIN_MS;
      return DELAY_MIN_MS + Math.floor(Math.random() * span);
    }

    function wait(ms) {
      return new Promise(resolve => setTimeout(resolve, ms));
    }

    /// Polls for the first element matching any of `selectors`
    /// up to `timeout` ms. Returns the element or null. Used to
    /// wait for LinkedIn's lazy-rendered action bar after a
    /// navigation lands.
    async function waitForAnySelector(selectors, timeout = 10_000) {
      const deadline = Date.now() + timeout;
      while (Date.now() < deadline) {
        for (const sel of selectors) {
          const el = document.querySelector(sel);
          if (el && el.offsetParent !== null) return el;
        }
        await wait(250);
      }
      return null;
    }

    /// Polls every selector in the More-button pool until one
    /// matches a VISIBLE element. We can't just return the first
    /// `querySelector` hit — some pool entries match hidden
    /// off-screen action bars (Sales Nav still renders one in the
    /// background of certain layouts), and clicking those does
    /// nothing. Filtering on `offsetParent` + bounding-rect width
    /// keeps the click on the real interactive button.
    ///
    /// **Text-content fallback.** LinkedIn's current public-
    /// profile layout ships the overflow button with NO
    /// aria-label and obfuscated class names — only the visible
    /// text "More" identifies it. Once the aria-label pool runs
    /// dry we walk `main button`s and pick the first visible one
    /// whose trimmed text is exactly "More" (not "… more", which
    /// is the activity-feed post truncator). The exact-match keeps
    /// the action-bar overflow from getting confused with the
    /// per-post expanders that sit below it.
    async function findMoreButton(timeout = 15_000) {
      const deadline = Date.now() + timeout;
      while (Date.now() < deadline) {
        // Aria-label / class-based selectors first — most specific.
        for (const sel of MORE_BUTTON_SELECTORS) {
          const matches = document.querySelectorAll(sel);
          for (const el of matches) {
            if (isVisibleElement(el)) return el;
          }
        }
        // Text-content fallback for the no-aria-label case.
        const mainButtons = document.querySelectorAll("main button");
        for (const el of mainButtons) {
          if (!isVisibleElement(el)) continue;
          const text = (el.textContent || "").trim();
          // Exact "More" — never the "… more" post-body expanders
          // (note: those use an actual ellipsis character + a
          // space, so "More" vs "… more" string equality is the
          // discriminator).
          if (text === "More" || text === "More actions") {
            return el;
          }
        }
        await wait(300);
      }
      return null;
    }

    /// `offsetParent` + non-zero bounding rect — the canonical
    /// "is this element actually showing on screen" check.
    /// Hoisted so both the aria-label and text-content paths use
    /// the same definition.
    function isVisibleElement(el) {
      if (!(el instanceof HTMLElement)) return false;
      if (el.offsetParent === null) return false;
      const rect = el.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    }

    /// Dumps a console diagnostic when `findMoreButton` runs out
    /// of selectors. Lists every interactive button in `main`
    /// with its aria-label, visible text, and class names so a
    /// failed run produces a usable signal in Safari's Develop →
    /// Show Web Inspector console rather than just a "More button
    /// not found" stop. Open the console after a failure and
    /// paste the dump back to the team — that's how the selector
    /// pool gets updated.
    function debugDumpButtons() {
      const btns = Array.from(document.querySelectorAll("main button, main a[role='button']"));
      const candidates = btns
        .filter(b => b instanceof HTMLElement && b.offsetParent !== null)
        .slice(0, 40)
        .map(b => ({
          aria: b.getAttribute("aria-label") || "(none)",
          text: (b.textContent || "").trim().slice(0, 60) || "(empty)",
          haspopup: b.getAttribute("aria-haspopup") || "—",
          classes: (b.className || "").split(/\s+/).slice(0, 3).join(" ") || "(none)"
        }));
      console.warn("[AMCRM walker] More button not found. Visible main-column buttons:", candidates);
      console.warn(
        "[AMCRM walker] Paste the table above to update MORE_BUTTON_SELECTORS in content.js. " +
        "Look for entries whose `aria` mentions 'more' or whose `haspopup` is 'true' near the profile header."
      );
    }

    /// Polls the open dropdown for a visible Save-to-PDF menu
    /// item. LinkedIn's dropdown is React-rendered after the
    /// More click — the items can take anywhere from a tick to
    /// a couple seconds to materialize, especially on the
    /// URN-redirected public-profile view of out-of-network
    /// leads. A single peek at 450ms misses inconsistently.
    /// This polls every 250ms up to `timeout` and only accepts
    /// VISIBLE matches so a hidden menu from a previous click
    /// state doesn't fool us.
    async function findSaveToPDFItem(timeout = 5_000) {
      const deadline = Date.now() + timeout;
      while (Date.now() < deadline) {
        const candidates = Array.from(document.querySelectorAll(
          '[role="menuitem"], .artdeco-dropdown__item, button, a, div[aria-label], li, span'
        ));
        const item = candidates.find(el => {
          if (!isVisibleElement(el)) return false;
          const t = (el.textContent || "").trim();
          const a = el.getAttribute("aria-label") || "";
          return SAVE_TO_PDF_LABEL_PATTERN.test(t) || SAVE_TO_PDF_LABEL_PATTERN.test(a);
        });
        if (item) return item;
        await wait(250);
      }
      return null;
    }

    /// Diagnostic dump when no Save-to-PDF item appears in the
    /// menu. Lists every visible menu-shaped element so the
    /// console reveals what the dropdown DID render — useful
    /// for distinguishing "menu didn't open" (no menuitems at
    /// all) from "Save to PDF item renamed" (other items
    /// present but no match) from "out-of-network profile —
    /// Save to PDF not offered" (menu opened but only "Report"
    /// / "Block" type entries).
    function debugDumpMenuItems() {
      const candidates = Array.from(document.querySelectorAll(
        '[role="menuitem"], .artdeco-dropdown__item, .artdeco-dropdown__content button, .artdeco-dropdown__content a'
      ))
        .filter(el => el instanceof HTMLElement && el.offsetParent !== null)
        .slice(0, 30)
        .map(el => ({
          tag: el.tagName.toLowerCase(),
          role: el.getAttribute("role") || "(none)",
          text: (el.textContent || "").trim().slice(0, 80) || "(empty)",
          aria: el.getAttribute("aria-label") || "(none)"
        }));
      console.warn("[AMCRM walker] Save-to-PDF menu item not found. Visible menu items:", candidates);
      if (candidates.length === 0) {
        console.warn("[AMCRM walker] The dropdown menu doesn't appear to have rendered at all. Either the More click didn't open it, or this LinkedIn profile (out of network / restricted view) doesn't offer the option.");
      }
    }

    /// Opens the More menu on a `/in/{slug}` page, finds the
    /// "Save to PDF" item, and clicks it. Throws when either
    /// element doesn't surface inside the polling window — the
    /// caller marks the row failed and continues with the next
    /// queue item. On a missed More button OR a missed menu
    /// item, we dump the candidate list to the console so the
    /// failure tells us what's actually on the page.
    async function triggerSaveToPDF() {
      const moreBtn = await findMoreButton(15_000);
      if (!moreBtn) {
        debugDumpButtons();
        throw new Error("More button not found (see Safari console for candidates)");
      }
      log(`Walker: clicking More button — aria="${moreBtn.getAttribute("aria-label") || ""}"`);
      moreBtn.click();
      // Poll for up to 5s for the Save-to-PDF item to appear
      // in the rendered dropdown. The old single-peek-at-450ms
      // approach missed inconsistently on slower page loads.
      const item = await findSaveToPDFItem(5_000);
      if (!item) {
        debugDumpMenuItems();
        throw new Error("Save to PDF item not found (see Safari console for candidates)");
      }
      log(`Walker: clicking Save to PDF — text="${(item.textContent || "").trim().slice(0, 40)}"`);
      item.click();
      // Give the browser a beat to start the download. LinkedIn's
      // export occasionally pops a "preparing your PDF…" modal
      // for ~3s before the file lands; 5s covers the typical case
      // without dragging the whole queue.
      await wait(5_000);
    }

    /// On `/sales/lead/...` pages, locate the public-profile
    /// anchor and follow it. Polls up to `timeout` ms because
    /// Sales Nav v3 lazy-renders the public-profile link after
    /// the rest of the action bar paints — a single-pass check
    /// at script load misses on first paint.
    ///
    /// When multiple anchors match and we know the expected slug
    /// (extracted from the queue item's publicURL when we had
    /// one but it was empty), we prefer the anchor whose href
    /// contains that slug — keeps the redirect honest when the
    /// page has activity-feed posts that also link to the same
    /// profile via `/in/{slug}/recent-activity/`.
    ///
    /// Returns true when navigation was kicked off; false when
    /// no link could be located inside the polling window
    /// (caller then dumps a diagnostic + marks the row failed).
    async function findPublicProfileLink(expectedSlug, timeout = 15_000) {
      const deadline = Date.now() + timeout;
      const selector = PUBLIC_PROFILE_LINK_SELECTORS.join(",");
      while (Date.now() < deadline) {
        const anchors = Array.from(document.querySelectorAll(selector));
        const usable = anchors.filter(a => {
          if (!(a instanceof HTMLElement) || !a.href) return false;
          const href = a.href.toLowerCase();
          // Public profile URLs have `/in/{slug}` — reject any
          // href that's a `/sales/lead/` link or anything else
          // that slipped through the selector net.
          if (!href.includes("/in/")) return false;
          if (href.includes("/sales/lead/")) return false;
          // Don't navigate to a /recent-activity/ or /detail/
          // subpage — strip those at follow time.
          return true;
        });
        if (usable.length === 0) {
          await wait(300);
          continue;
        }
        // Prefer the anchor whose slug matches what the queue
        // expected, else default to the first usable one.
        let chosen = usable[0];
        if (expectedSlug) {
          const better = usable.find(a => a.href.toLowerCase().includes(expectedSlug.toLowerCase()));
          if (better) chosen = better;
        }
        return chosen;
      }
      return null;
    }

    /// Diagnostic dump for failed public-profile redirects —
    /// same shape as `debugDumpButtons`. Lists every anchor on
    /// the page with a hint of an `/in/` URL so we can update
    /// the selector pool if Sales Nav rewrites the link.
    function debugDumpProfileAnchors() {
      const anchors = Array.from(document.querySelectorAll("a"));
      const candidates = anchors
        .filter(a => a instanceof HTMLElement && a.offsetParent !== null)
        .filter(a => (a.href || "").toLowerCase().includes("linkedin.com/in/"))
        .slice(0, 20)
        .map(a => ({
          href: a.href.slice(0, 100),
          text: (a.textContent || "").trim().slice(0, 40) || "(empty)",
          classes: (a.className || "").split(/\s+/).slice(0, 3).join(" ") || "(none)"
        }));
      console.warn("[AMCRM walker] No public-profile link found on Sales Nav page. /in/ anchors present:", candidates);
    }

    /// Append a per-item outcome to the persisted results array
    /// so the overlay's final report shows what happened across
    /// the whole run.
    async function recordResult(index, status, message) {
      const state = await readState();
      const results = state.results.slice();
      results.push({ index, status, message: message || "" });
      await writeState({ [STORAGE_RESULTS]: results });
    }

    /// Advance the cursor and schedule the next navigation.
    /// `success` flags whether the just-finished item actually
    /// saved a PDF (vs failed) — the run continues either way,
    /// but the results log differs.
    async function advance(success, message) {
      const state = await readState();
      const newCursor = state.cursor + 1;
      const done = newCursor >= state.queue.length;
      // Record the page we just handled — on SKIP as well as on a
      // successful save — so the next tick can tell "I've already left
      // this page" apart from "I'm sitting on the target." Recording it
      // ONLY on success (the old behavior) is what caused the off-by-one
      // desync: after a skip the cursor advanced but `lastSavedPath`
      // stayed stale, so `currentPageMatchesTarget`'s URN branch accepted
      // the skipped lead's page as the NEXT lead's and the walker saved
      // the wrong profile. `here` is the path we're leaving.
      const here = location.pathname;
      await recordResult(
        state.cursor,
        success ? "ok" : "fail",
        message
      );
      if (done) {
        await writeState({
          [STORAGE_CURSOR]: newCursor,
          [STORAGE_NEXT_AT]: 0,
          [STORAGE_LAST_SAVED_PATH]: here,
          [STORAGE_STATUS_MSG]: success
            ? `Saved final PDF (${state.queue.length} of ${state.queue.length}).`
            : `Finished with errors — see results.`
        });
        await renderOverlay(true);
        // Briefly hold on the current page; the user closes the
        // overlay manually when they're done.
        return;
      }
      const delay = pickDelay();
      const nextAt = Date.now() + delay;
      await writeState({
        [STORAGE_CURSOR]: newCursor,
        [STORAGE_NEXT_AT]: nextAt,
        [STORAGE_LAST_SAVED_PATH]: here,
        [STORAGE_STATUS_MSG]: success
          ? `Saved PDF for lead ${state.cursor + 1}. Waiting ${Math.round(delay / 60_000)} min before next.`
          : `Skipped lead ${state.cursor + 1}: ${message || "unknown error"}. Continuing.`
      });
      await renderOverlay(true);
      // Schedule the navigation to the next item.
      scheduleNavigation(nextAt);
    }

    /// Sets up the timer that flips the script over to the next
    /// item's URL when the delay window expires. Storing
    /// `nextAt` lets a tab reload during sleep re-arm the same
    /// timer rather than reset the clock.
    function scheduleNavigation(nextAt) {
      if (navigationTimer) clearTimeout(navigationTimer);
      const delay = Math.max(0, nextAt - Date.now());
      navigationTimer = setTimeout(async () => {
        const state = await readState();
        if (state.cursor >= state.queue.length) return;
        const next = state.queue[state.cursor];
        const dest = targetURL(next);
        if (!dest) {
          await advance(false, "no URL for this lead");
          return;
        }
        location.href = dest;
      }, delay);
    }

    /// True when the page we're on matches the cursor's target —
    /// either the canonical `/in/{slug}` for a profile target
    /// (URN-shaped wants accept any `/in/` slug since LinkedIn
    /// redirects URN paths to the canonical), or the matching
    /// `/sales/lead/{URN}` for a Sales Nav target. The walker
    /// uses this to decide between "do the action on this page"
    /// vs "navigate to the right page first" — a stalled tab
    /// (e.g. timer throttled after Safari backgrounded the tab
    /// while the Save-to-PDF popup was open) sits on the
    /// PREVIOUS lead's profile, and the old code's slug-match
    /// guard treated that as a wrong-person redirect and bailed
    /// the row. This helper makes the recovery path explicit:
    /// "you're on the wrong page → navigate to the right one".
    ///
    /// **URN match guard.** The URN-target branch used to accept
    /// any `/in/` slug as a match — fine when we'd just navigated
    /// to `/in/{URN}` and LinkedIn redirected to the canonical
    /// slug, BAD when we're still on the previous lead's profile
    /// during the inter-item delay (cursor has advanced, page
    /// hasn't). A re-firing tick (visibility change, stale
    /// timer) would accept the previous page and re-save the
    /// same PDF. `lastSavedPath` records the path we last saved
    /// a PDF for; the URN branch returns false when we're still
    /// sitting on that exact path so the navigation fires
    /// instead of the duplicate save.
    function currentPageMatchesTarget(targetURL, lastSavedPath) {
      if (!targetURL) return false;
      let parsed;
      try { parsed = new URL(targetURL); } catch (_) { return false; }
      const path = parsed.pathname;
      const inMatch = path.match(/\/in\/([^/?#]+)/i);
      if (inMatch) {
        const wantSlug = inMatch[1];
        const have = location.pathname.match(/\/in\/([^/?#]+)/i);
        if (!have) return false;
        if (looksLikeURN(wantSlug)) {
          // URN target: any `/in/` slug counts AS LONG AS we
          // haven't just saved a PDF from that exact path. If
          // we have, the cursor has moved forward but we're
          // still on the OLD page — return false so tick
          // navigates to the new target.
          if (lastSavedPath && lastSavedPath.toLowerCase() === location.pathname.toLowerCase()) {
            return false;
          }
          return true;
        }
        return wantSlug.toLowerCase() === have[1].toLowerCase();
      }
      const salesMatch = path.match(/\/sales\/lead\/([^/?#,]+)/i);
      if (salesMatch) {
        return location.pathname.includes(`/sales/lead/${salesMatch[1]}`);
      }
      return false;
    }

    /// Main per-page entry point. Bootstraps from `?amcrm_queue=`
    /// when present, then runs whatever step matches the current
    /// page + cursor state.
    async function tick() {
      if (inFlight) return;
      inFlight = true;
      try {
        // ABSOLUTE GATE: the walker runs ONLY when a session is
        // explicitly active. The session flag is set by:
        //   1. popup.js when the user clicks Download
        //   2. maybeBootstrap when an ?amcrm_queue= URL fires
        // …and cleared by clearQueue (queue done / send-followup
        // took over). Any other page load — Send Follow-up,
        // ambient LinkedIn browsing, visibilitychange re-ticks —
        // finds the flag unset and the walker no-ops. This is the
        // permanent fix for the "walker hijacks Send Follow-up"
        // class of bugs: if the walker isn't running, it can't
        // navigate. Bootstrap path below sets the flag itself
        // before the queue is read, so a fresh ?amcrm_queue=
        // URL still kicks the walker off normally.
        const hasURLBootstrap = location.search.includes("amcrm_queue=");
        if (!hasURLBootstrap) {
          try {
            const flag = await browser.storage.local.get(STORAGE_SESSION_ACTIVE);
            if (!(flag && flag[STORAGE_SESSION_ACTIVE])) {
              return;
            }
          } catch (err) {
            // Storage read failure — fail closed (bail) so a
            // glitch doesn't trigger a navigation.
            return;
          }
        }
        // Bail out the moment a send-followup bootstrap is
        // present on this page load — either in the URL (fresh
        // open from the inspector's Send button) or in storage
        // (the bootstrap that already ran on this load).
        // Without this, a stale `amcrm_walker_queue` from a prior
        // bulk-download session navigates Safari AWAY from the
        // profile the user just opened to the queue's current
        // cursor target, breaking the Send Follow-up flow and
        // sometimes dragging the tab into Sales Navigator.
        //
        // We also CLEAR the stale walker queue when we bail, not
        // just defer. Otherwise the visibilitychange re-tick fires
        // a few seconds later (when the user clicks back into the
        // tab after pasting in LinkedIn's composer) AFTER
        // SEND_FOLLOWUP has already cleared amcrm_send_text from
        // storage — at which point the bail doesn't trip and the
        // stale queue takes over. Wiping the queue here means
        // subsequent ticks have nothing to chase; the popup's
        // Bulk Download button repopulates the queue when the
        // user starts a fresh run.
        const sendFollowupActive = await (async () => {
          if (location.search.includes("amcrm_send_text=")) return true;
          try {
            const pending = await browser.storage.local.get("amcrm_send_text");
            return !!(pending && pending.amcrm_send_text);
          } catch (err) {
            return false;
          }
        })();
        if (sendFollowupActive) {
          log("Walker: deferring + clearing stale queue — send-followup owns this tab.");
          try {
            await clearQueue();
          } catch (err) {
            console.error("[AMCRM walker] clearQueue failed during send-followup bail:", err);
          }
          return;
        }
        await maybeBootstrap();
        const state = await readState();
        if (state.queue.length === 0) return;
        if (state.cursor >= state.queue.length) {
          // Run is over — render the final overlay and clear the
          // queue keys so the next bootstrap starts fresh.
          await renderOverlay(true);
          await clearQueue();
          return;
        }
        await renderOverlay(true);

        // If we're still in the delay window for the previous
        // item's save, re-arm the timer and wait it out.
        if (state.nextAt > Date.now()) {
          scheduleNavigation(state.nextAt);
          return;
        }

        const current = state.queue[state.cursor];
        const dest = targetURL(current);
        if (!dest) {
          await advance(false, "no URL for this lead");
          return;
        }

        // **Recovery check.** Before any surface-specific
        // handling, verify we're on the page that matches the
        // cursor. If not, navigate there. This catches the
        // stalled-tab case where Safari throttled the
        // setTimeout while a Save-to-PDF popup was open: the
        // walker tab is still on the PREVIOUS lead's profile,
        // cursor has advanced, but auto-navigation never fired.
        // When the user clicks back to the tab (or hits the
        // overlay's "Next now" button), this branch fires and
        // moves us to the right URL.
        //
        // We pass `lastSavedPath` so URN-shaped targets don't
        // falsely match the previous lead's page (see
        // `currentPageMatchesTarget`'s URN match guard).
        if (!currentPageMatchesTarget(dest, state.lastSavedPath)) {
          await writeState({ [STORAGE_STATUS_MSG]: `Navigating to ${current.name || "next lead"}…` });
          await renderOverlay(true);
          location.href = dest;
          return;
        }

        // Sales Nav surface — only reached when the cursor's
        // target IS the current Sales Nav page (e.g. a manual
        // Sales Nav-only run). The URN-derivation in popup.js +
        // SalesNavPDFAutoDownloadLauncher means the queue
        // normally points at /in/{URN} directly, so this branch
        // is rare in practice but kept for defense in depth.
        if (onSalesLeadPage) {
          await writeState({ [STORAGE_STATUS_MSG]: "Looking for the public-profile link on this Sales Nav page…" });
          await renderOverlay(true);
          const slugMatch = (current.publicURL || "").match(/\/in\/([^/?#]+)/i);
          const expectedSlug = slugMatch ? slugMatch[1] : "";
          const anchor = await findPublicProfileLink(expectedSlug, 15_000);
          if (!anchor) {
            debugDumpProfileAnchors();
            await advance(false, "no public-profile link on Sales Nav page (see Safari console for candidate anchors)");
            return;
          }
          let dest = anchor.href.split("?")[0].split("#")[0];
          dest = dest.replace(/\/(recent-activity|detail|overlay)\/?$/i, "");
          if (!dest.endsWith("/")) dest = dest + "/";
          log(`Walker: redirecting Sales Nav → public profile: ${dest}`);
          location.href = dest;
          return;
        }

        // Profile page — we already confirmed
        // `currentPageMatchesTarget`, so this is the right
        // profile (or LinkedIn redirected from URN to canonical,
        // which counts as right). Run Save-to-PDF.
        if (onProfilePage) {
          const haveSlug = (location.pathname.match(/\/in\/([^/?#]+)/i) || [])[1] || "";
          const captureModeLabel = state.captureMode === "screenshot"
            ? "Screenshotting"
            : "Saving PDF for";
          await writeState({ [STORAGE_STATUS_MSG]: `${captureModeLabel} ${current.name || haveSlug}…` });
          await renderOverlay(true);
          try {
            // Branch on the queue's capture mode. PDFs go through
            // LinkedIn's own Save-to-PDF menu (rate-limited at
            // their end, but produces a true PDF). Screenshots
            // scroll-and-stitch the page locally — no LinkedIn
            // server-side rate limit, just per-viewport
            // captureVisibleTab calls — and download a PNG.
            if (state.captureMode === "screenshot") {
              await SCREENSHOT.captureFullProfileScreenshot();
            } else {
              await triggerSaveToPDF();
            }
            // `advance()` records the path we just handled (for skips
            // too) so the next tick knows we've left this page — see
            // `currentPageMatchesTarget`'s URN match guard.
            await advance(true, "");
          } catch (err) {
            const msg = err && err.message ? err.message : String(err);
            await writeState({
              [STORAGE_STATUS_MSG]: `Skip: ${msg}. See Safari → Develop → Show JavaScript Console for details.`
            });
            await renderOverlay(true);
            await advance(false, msg);
          }
          return;
        }
      } finally {
        inFlight = false;
      }
    }

    /// Force the navigation to the NEXT cursor item immediately
    /// — used by the overlay's "Next now" button and by the
    /// visibility-recovery path when a stalled setTimeout has
    /// passed its scheduled wake-up time. Sets nextAt to a
    /// past timestamp and routes through `tick` so the same
    /// recovery / current-vs-target logic applies.
    async function advanceNow() {
      const state = await readState();
      if (state.queue.length === 0) return;
      if (state.cursor >= state.queue.length) return;
      log("Walker: manual / recovery advance fired");
      if (navigationTimer) {
        clearTimeout(navigationTimer);
        navigationTimer = null;
      }
      // Clear the delay window so tick() doesn't bounce off
      // the `state.nextAt > Date.now()` early return.
      await writeState({ [STORAGE_NEXT_AT]: 0 });
      await tick();
    }

    /// Visibility recovery — Safari aggressively throttles
    /// setTimeout in background tabs. When LinkedIn's
    /// "Save to PDF" opens a popup the walker tab drops to
    /// background and the inter-item delay timer can stall
    /// indefinitely. Listening for visibilitychange lets the
    /// walker resume the moment the user clicks back into the
    /// tab — if the scheduled nextAt has passed, tick will
    /// re-fire the navigation; if not, the existing timer
    /// continues.
    let visibilityRegistered = false;
    function ensureVisibilityListener() {
      if (visibilityRegistered) return;
      visibilityRegistered = true;
      document.addEventListener("visibilitychange", () => {
        if (document.visibilityState !== "visible") return;
        log("Walker: tab visible — re-running tick to check for stalled advance");
        tick().catch(err => console.error("[AMCRM walker] visibility re-tick failed:", err));
      });
    }

    return { tick, isActive, maybeBootstrap, readState, advanceNow, ensureVisibilityListener };
  })();

  // Kick the walker on every page load. The function self-gates
  // (no-ops when no queue is installed and no bootstrap param is
  // present), so it's safe to call on every Sales Nav / Marketplace
  // / profile page visit.
  WALKER.tick().catch(err => console.error("[AMCRM walker tick]", err));
  WALKER.ensureVisibilityListener();

  // =========================================================
  // Full-page profile screenshot (scroll-and-stitch)
  // =========================================================
  //
  // Used by:
  //   - The popup's "Capture this profile" button (one-shot
  //     capture of the current /in/ page)
  //   - The walker, when the user has flipped the "Use
  //     screenshots instead of PDFs" toggle. The walker calls
  //     `captureFullProfileScreenshot` in place of
  //     `triggerSaveToPDF` so the inter-item delay + cursor
  //     advance flow remain identical.
  //
  // The content script can't call `browser.tabs.captureVisibleTab`
  // itself (privileged API) so each viewport-sized capture
  // round-trips through background.js. We scroll the page in
  // viewport-tall chunks, request a capture per chunk, then
  // stitch the chunks into a single tall canvas and download it
  // as a PNG. Fixed / sticky headers are hidden after the first
  // chunk so they don't repeat in every captured slice.

  const SCREENSHOT = (() => {
    /// Local copy of the WALKER's visibility check — that one is
    /// scoped to the WALKER IIFE and isn't reachable here.
    /// SEND_FOLLOWUP defines its own `isVisibleEl` for the same
    /// reason; this IIFE needs its own too. v0.1.165's expansion
    /// pass called the WALKER's `isVisibleElement` directly and
    /// only worked when the runtime happened to hoist it across
    /// IIFE boundaries on some Safari builds; v0.1.175 broadened
    /// the usage and the scope bug exploded on every walker run
    /// with "Can't find variable: isVisibleElement."
    function isVisibleElement(el) {
      if (!(el instanceof HTMLElement)) return false;
      if (el.offsetParent === null) return false;
      const rect = el.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    }

    /// Pulls the most-visible profile name off the page. LinkedIn
    /// public profile pages put the lead's name in the first
    /// `<h1>` inside `<main>`; the `<title>` is a reasonable
    /// fallback when the h1 isn't where we expect.
    function extractProfileName() {
      const h1 = document.querySelector("main h1");
      if (h1) {
        const text = (h1.textContent || "").trim();
        if (text) return text;
      }
      const title = (document.title || "").replace(/\s*\|\s*LinkedIn\s*$/i, "").trim();
      return title || "LinkedIn Profile";
    }

    /// Sanitizes a filename to drop characters that the macOS
    /// downloader / Finder dislike. Keeps Unicode letters and
    /// hyphens / underscores / spaces / em-dashes; replaces the
    /// rest with `-`.
    function safeFilename(input) {
      return String(input || "Profile")
        .replace(/[\\/:*?"<>|]/g, "-")
        .replace(/\s+/g, " ")
        .trim()
        .slice(0, 120) || "Profile";
    }

    function todayStamp() {
      const d = new Date();
      const y = d.getFullYear();
      const m = String(d.getMonth() + 1).padStart(2, "0");
      const day = String(d.getDate()).padStart(2, "0");
      return `${y}-${m}-${day}`;
    }

    /// Pauses `ms` milliseconds without blocking the event loop.
    function pause(ms) {
      return new Promise(resolve => setTimeout(resolve, ms));
    }

    async function loadImage(dataURL) {
      return new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = () => resolve(img);
        img.onerror = reject;
        img.src = dataURL;
      });
    }

    /// Picks fixed / sticky elements out of the page that would
    /// otherwise repeat in every captured chunk (LinkedIn's top
    /// navigation bar is the worst offender). We don't try to be
    /// clever about WHICH ones to hide — anything `position:
    /// fixed | sticky` AND visible AND near the top of the page
    /// is fair game for the duration of the capture run.
    function collectFixedHeaders() {
      const result = [];
      const candidates = document.querySelectorAll("header, nav, [role='banner'], .global-nav, .scaffold-layout__sticky-content");
      for (const el of candidates) {
        if (!(el instanceof HTMLElement)) continue;
        const style = window.getComputedStyle(el);
        if (style.position !== "fixed" && style.position !== "sticky") continue;
        if (el.offsetParent === null) continue;
        const rect = el.getBoundingClientRect();
        // Only hide headers anchored near the top — preserve
        // legitimate sticky widgets further down the page.
        if (rect.top > 200) continue;
        result.push(el);
      }
      return result;
    }

    /// Requests a single viewport-sized PNG capture from the
    /// background service worker. Returns the dataURL string, or
    /// throws if the worker reports a failure.
    async function captureViewportPNG() {
      const response = await browser.runtime.sendMessage({ type: "captureVisibleTab" });
      if (!response || !response.ok || !response.dataURL) {
        throw new Error((response && response.error) || "captureVisibleTab returned no data");
      }
      return response.dataURL;
    }

    /// Reads the current full-document height. LinkedIn lazy-
    /// loads profile sections (Experience, Education,
    /// Recommendations, Activity feed) as the user scrolls, so
    /// this value GROWS during capture — the previous version
    /// measured once at start and terminated after one chunk
    /// when the initial small height was reached. Now this
    /// helper gets called on every loop iteration.
    function measureScrollHeight() {
      const inner = findInnerScrollContainer();
      const inner_h = inner ? inner.scrollHeight : 0;
      return Math.max(
        document.documentElement.scrollHeight || 0,
        document.body.scrollHeight || 0,
        document.documentElement.offsetHeight || 0,
        inner_h
      );
    }

    /// Finds the element that's actually doing the scrolling
    /// on this page. Modern LinkedIn profile pages document-
    /// scroll, but some Sales Nav / Marketplace layouts (and
    /// occasionally /in/ pages with full-window apps) put the
    /// content inside a nested overflow container. When
    /// `window.scrollTo` doesn't move the visible viewport, we
    /// fall back to scrolling whichever inner container has the
    /// most scrollable content.
    ///
    /// Returns null when the document itself is the scroller
    /// (the common case) — `scrollIntoCurrentContainer` then
    /// only calls `window.scrollTo`.
    function findInnerScrollContainer() {
      const candidates = [
        document.querySelector("main"),
        document.querySelector(".scaffold-layout"),
        document.querySelector(".scaffold-layout__inner"),
        document.querySelector(".application-outlet"),
        document.querySelector(".authentication-outlet"),
        document.querySelector('[data-test-id*="scaffold"]')
      ];
      let best = null;
      let bestExtra = 0;
      for (const el of candidates) {
        if (!(el instanceof HTMLElement)) continue;
        const sh = el.scrollHeight || 0;
        const ch = el.clientHeight || 0;
        const extra = sh - ch;
        if (extra > bestExtra && extra > 200) {
          best = el;
          bestExtra = extra;
        }
      }
      return best;
    }

    /// Scrolls to `y` and verifies the move actually happened.
    /// Returns the actual scroll position after the move (which
    /// may differ from `y` if the page is shorter than expected,
    /// or 0 if the scroll silently failed).
    ///
    /// Tries window.scrollTo first; if that didn't move the
    /// viewport (some LinkedIn layouts have a nested scroll
    /// container that intercepts), falls back to scrolling the
    /// largest scrollable inner element. Logs which path took
    /// so a future scroll-stall diagnosis tells us if the page
    /// scrolls the document or a child.
    async function scrollToY(y) {
      const before = window.scrollY;
      window.scrollTo(0, y);
      await pause(150);
      const afterWindow = window.scrollY;
      if (afterWindow !== before || y === 0) {
        // Window scroll worked (or we explicitly went to 0).
        return { y: afterWindow, via: "window" };
      }
      // Window scroll didn't move us — try the inner container.
      const inner = findInnerScrollContainer();
      if (!inner) {
        return { y: window.scrollY, via: "window-stuck" };
      }
      const innerBefore = inner.scrollTop;
      inner.scrollTop = y;
      await pause(150);
      const innerAfter = inner.scrollTop;
      if (innerAfter !== innerBefore) {
        return { y: innerAfter, via: "inner" };
      }
      return { y: window.scrollY, via: "both-stuck" };
    }

    /// Walks the rendered DOM and clicks every visible inline-
    /// expander button (LinkedIn's "...see more" / "Show more"
    /// affordances on About + Experience descriptions). Repeats
    /// up to MAX_PASSES because expanding one section can reveal
    /// nested expanders inside it. Skips anything that looks like
    /// a navigation link (button inside `<a href>`, or "Show all
    /// N" / "see more results" patterns) so we never accidentally
    /// leave the current profile.
    async function expandAllInlineSections() {
      // Bumped from 5 → 8 passes + 350ms → 600ms pause: some
      // sections take 2-3 passes to fully unfurl (parent
      // expander reveals child, child reveals grandchild), and
      // LinkedIn's React relayout can take >350ms on a long
      // profile under load.
      const MAX_PASSES = 8;
      const PER_PASS_CAP = 80;
      const RELAYOUT_PAUSE = 600;
      let totalClicked = 0;

      for (let pass = 0; pass < MAX_PASSES; pass++) {
        const buttons = findInlineExpanders();
        if (buttons.length === 0) break;

        let clickedThisPass = 0;
        for (const btn of buttons) {
          if (clickedThisPass >= PER_PASS_CAP) break;
          try {
            btn.click();
            clickedThisPass++;
            totalClicked++;
          } catch (_) { /* swallow — keep walking */ }
        }
        if (clickedThisPass === 0) break;
        // Let LinkedIn's React layer re-render the now-expanded
        // sections before we re-scan for nested expanders.
        await pause(RELAYOUT_PAUSE);
      }
      return totalClicked;
    }

    /// Collects every inline-expander button currently in the DOM.
    /// Three tiers, deduped:
    ///   1. **Class-based** — LinkedIn's stable internal class
    ///      names for inline expansion controls. Most reliable.
    ///   2. **aria-label-based** — buttons whose accessible name
    ///      is "see more" / "show more" (excluding navigations).
    ///   3. **Text-content-based** — buttons whose visible text is
    ///      exactly "see more" / "…more" / "show more". Excludes
    ///      buttons that count items ("Show all 23") or sit inside
    ///      a link, which would be navigations.
    function findInlineExpanders() {
      // Scope over the whole document — using `<main>` alone
      // missed expanders on Sales Navigator lead pages where the
      // content shell sits outside `<main>`, and on LinkedIn's
      // newer React-rebuilt profile sections that root in
      // `<body>` directly. Scoping wide is safe because every
      // tier below filters for visible interactive elements.
      const scope = document;
      const out = [];
      const seen = new Set();
      const push = el => {
        if (!seen.has(el)) { seen.add(el); out.push(el); }
      };

      // **Action-menu guard — applied to every tier.** LinkedIn's
      // profile action bar has a kebab "More" button (next to
      // Message / Connect) that opens a menu of Block / Report /
      // etc. It's text-content "More" with `aria-haspopup`. v0.1.175
      // broadened the matchers to text="more" + aria-label*="expand"
      // and started catching that kebab — it would pop the action
      // menu mid-capture instead of expanding text. Skip any
      // candidate that declares it opens a popup (menu, listbox,
      // dialog) — text expanders never do.
      const hasPopup = el => {
        const popup = (el.getAttribute("aria-haspopup") || "").toLowerCase();
        // The HTML attribute value can be: "true", "menu",
        // "listbox", "tree", "grid", "dialog", or "false". Any
        // truthy value indicates this button opens a popup, which
        // an inline text-expander never does.
        return popup === "true"
            || popup === "menu"
            || popup === "listbox"
            || popup === "tree"
            || popup === "grid"
            || popup === "dialog";
      };

      // Tier 1 — class-based. LinkedIn's class names for inline
      // expanders are remarkably stable across redesigns. Stripped
      // the v0.1.175 generic `[class*='expand']` /
      // `[class*='show-more']` / `[class*='read-more']` selectors
      // because they also matched action-bar buttons (e.g.
      // `artdeco-dropdown__trigger--expanded`,
      // `profile-actions__show-more`); these were the bare-`more`
      // false-positive vector. Kept the LinkedIn-specific
      // `inline-show-more-text`, `show-more-less-text`,
      // `lt-line-clamp`, and Sales Nav `_truncated-text` /
      // `_show-more-text` classes — those are unambiguously text
      // expanders.
      const classSelectors = [
        "button.inline-show-more-text__button",
        ".inline-show-more-text button",
        "button[class*='show-more-less-text']",
        ".show-more-less-text button",
        ".lt-line-clamp__more",
        "button[class*='lt-line-clamp']",
        // Sales Navigator-specific expander classes.
        "button[class*='_truncated-text']",
        "._show-more-text button",
        // Generic React-class pattern that wraps text expanders.
        "button[data-test-line-clamp-truncated-text]",
        // Data-test hooks specific to text expanders. The
        // attribute-substring match was too loose in v0.1.175 (it
        // also matched container `data-test-id`s like
        // `pv-more-actions`). Tighten to `*-text` suffixes used
        // by LinkedIn's truncate-text component family.
        "[data-test-id$='show-more-text'] button",
        "[data-test-id$='read-more-text'] button"
      ];
      for (const sel of classSelectors) {
        let nodes;
        try { nodes = scope.querySelectorAll(sel); }
        catch (_) { continue; /* ignore invalid selectors */ }
        for (const el of nodes) {
          if (!isVisibleElement(el)) continue;
          if (hasPopup(el)) continue;
          push(el);
        }
      }

      // Tier 2 — aria. Cover "see more" / "show more" / "read
      // more" only. Dropped the v0.1.175 `aria-label*="expand"`
      // matcher — it was catching menu triggers like "Expand
      // navigation" / "Expand profile menu". Inline text
      // expanders consistently use the verb-phrase labels.
      for (const el of scope.querySelectorAll('button[aria-label*="see more" i], button[aria-label*="show more" i], button[aria-label*="read more" i]')) {
        if (!isVisibleElement(el)) continue;
        if (hasPopup(el)) continue;
        const aria = (el.getAttribute("aria-label") || "").toLowerCase();
        if (aria.includes("show all")) continue;
        if (aria.includes("see all")) continue;
        if (aria.includes("see more results")) continue;
        if (aria.includes("show more results")) continue;
        // Skip explicitly-collapse intent.
        if (aria.includes("collapse")) continue;
        if (aria.includes("less")) continue;
        push(el);
      }
      for (const el of scope.querySelectorAll('button[aria-expanded="false"]')) {
        if (seen.has(el)) continue;
        if (!isVisibleElement(el)) continue;
        if (hasPopup(el)) continue;
        if (el.closest("a[href]")) continue;
        const text = (el.textContent || "")
          .replace(/\s+/g, " ")
          .trim()
          .toLowerCase();
        // Only fire on text-expander verbs. Bare "more" was
        // catching the action-bar kebab — restrict to phrases
        // that can ONLY be an inline text expander.
        if (text.includes("see more")
            || text.includes("show more")
            || text.includes("read more")
            || text === "…more"
            || text === "...more") {
          push(el);
        }
      }

      // Tier 3 — exact text match on plain buttons. **Bare "more"
      // is excluded** — that text on a button is almost always
      // the action-bar kebab on LinkedIn profiles, not an inline
      // text expander. Inline expanders consistently render as
      // "...more" / "…more" / "see more" / "show more" /
      // "read more"; the action kebab renders as just "More".
      for (const el of scope.querySelectorAll("button")) {
        if (seen.has(el)) continue;
        if (!isVisibleElement(el)) continue;
        if (hasPopup(el)) continue;
        // Exclude buttons whose closest ancestor is a link — that
        // shape is a navigation button decorated to look inline.
        if (el.closest("a[href]")) continue;
        const text = (el.textContent || "")
          .replace(/\s+/g, " ")
          .trim()
          .toLowerCase();
        if (text === "see more"
            || text === "show more"
            || text === "read more"
            || text === "…more"
            || text === "...more") {
          push(el);
        }
      }

      // Tier 4 — span / div with role="button". LinkedIn's
      // newer React composer uses focusable spans for some inline
      // expanders so they integrate with the surrounding text
      // flow. Same text + visibility + popup filter as Tier 3.
      for (const el of scope.querySelectorAll('[role="button"]:not(button):not(a)')) {
        if (seen.has(el)) continue;
        if (!isVisibleElement(el)) continue;
        if (hasPopup(el)) continue;
        if (el.closest("a[href]")) continue;
        const text = (el.textContent || "")
          .replace(/\s+/g, " ")
          .trim()
          .toLowerCase();
        if (text === "see more"
            || text === "show more"
            || text === "read more"
            || text === "…more"
            || text === "...more") {
          push(el);
        }
      }

      return out;
    }

    /// Prime + expand pass: scroll through the page once to force
    /// LinkedIn's lazy-loaded sections (Experience, Education,
    /// Recommendations) to render, then click every inline
    /// "...see more" / "Show more" button so the captured PNG
    /// carries the full text rather than truncated stubs. Returns
    /// to top before the chunk-capture loop begins so the first
    /// chunk shows the profile header.
    async function primeLazyContentAndExpand() {
      const viewportH = window.innerHeight;
      // Pass 1 — sweep top-to-bottom to trigger lazy-load. Use
      // 70% viewport stride so we don't skip section boundaries
      // that might be the trigger point for lazy-rendering.
      const stride = Math.max(200, Math.floor(viewportH * 0.7));
      let initialHeight = measureScrollHeight();
      let y = 0;
      let sweeps = 0;
      const MAX_SWEEPS = 80;
      while (y < initialHeight && sweeps < MAX_SWEEPS) {
        await scrollToY(y);
        await pause(200);
        y += stride;
        sweeps++;
        // Re-measure — lazy-loaded sections may have grown the
        // document; keep going to cover the new tail.
        const grown = measureScrollHeight();
        if (grown > initialHeight) initialHeight = grown;
      }
      // Hit the very bottom in case stride math overshot.
      await scrollToY(measureScrollHeight());
      await pause(400);

      // Pass 2 — back to top so the expand pass can scan from
      // the start; then expand inline expanders.
      await scrollToY(0);
      await pause(250);
      const expanded = await expandAllInlineSections();

      // Pass 3 — re-pause so the expanded sections finish
      // laying out before the chunk capture begins measuring.
      await pause(500);
      log(`Screenshot prime: lazy-load swept ${sweeps} steps, expanded ${expanded} inline section(s)`);
    }

    /// Main entry point. Scrolls the page in viewport-tall
    /// chunks, captures each chunk via the background worker,
    /// stitches into a single canvas, downloads as PNG. Returns
    /// the chosen filename so callers can log it.
    ///
    /// **Re-measurement loop.** Continues capturing until BOTH:
    ///   - we've scrolled past the current `scrollHeight`, AND
    ///   - the height didn't grow on the last scroll (no new
    ///     content was lazy-loaded into existence).
    /// Capped at 60 chunks total (~60 viewports = ~50,000px) so
    /// a runaway page can't capture indefinitely.
    async function captureFullProfileScreenshot() {
      const originalScroll = window.scrollY;
      const viewportH = window.innerHeight;
      const viewportW = window.innerWidth;
      const dpr = window.devicePixelRatio || 1;
      const MAX_CHUNKS = 60;
      const STABLE_HEIGHT_TOLERANCE = 100; // px — lazy-load fluctuates a bit

      log(`Screenshot: starting — viewport ${viewportW}x${viewportH}, dpr ${dpr}, initial height ${measureScrollHeight()}`);

      // Hide the walker's own floating overlay during capture
      // so it doesn't appear in every chunk. The overlay floats
      // bottom-right with position:fixed; collectFixedHeaders
      // only catches top-anchored fixed elements (rect.top ≤
      // 200) so the walker overlay slipped through and stamped
      // itself into every PNG.
      const walkerOverlay = document.getElementById("amcrm-walker-overlay");
      const walkerOverlayOriginalDisplay = walkerOverlay ? walkerOverlay.style.display : null;
      if (walkerOverlay) walkerOverlay.style.display = "none";

      await scrollToY(0);
      await pause(500);

      // Prime + expand pass BEFORE the chunk capture loop:
      //   1. Scroll the page top-to-bottom once to force LinkedIn's
      //      lazy-loaded sections (Experience, Education, etc.) to
      //      render — otherwise the expand pass below misses
      //      buttons that don't exist in the DOM yet.
      //   2. Walk the now-rendered DOM and click every inline
      //      "...see more" / "Show more" button on About blurbs +
      //      per-role Experience descriptions so the captured PNG
      //      carries the full text, not LinkedIn's truncated stub.
      //   3. Re-pause after the expansions so the document settles
      //      before chunk measurement begins.
      // Without this, About + Experience descriptions long enough
      // to be truncated landed in the briefing as half-sentences,
      // costing Adam the context he needs for personalized outreach.
      await primeLazyContentAndExpand();

      const fixedHeaders = collectFixedHeaders();
      const originalDisplay = fixedHeaders.map(el => el.style.display);

      const chunks = [];
      let y = 0;
      let lastHeight = 0;
      let stableCount = 0;
      try {
        while (chunks.length < MAX_CHUNKS) {
          const scrollResult = await scrollToY(y);
          // Wait for scroll to settle + lazy-load to fire +
          // newly-visible expanders to render. Split into two
          // halves so we can run a quick expand-in-viewport pass
          // mid-pause for sections that only renders their
          // "...see more" buttons after they scroll into view —
          // the initial primeLazyContentAndExpand() runs once
          // upfront and misses those.
          await pause(450);
          // Per-chunk expand. Cheap when there's nothing to
          // click (returns immediately); when there IS something,
          // expandAllInlineSections's own RELAYOUT_PAUSE between
          // its passes covers the layout cost.
          const expandedHere = await expandAllInlineSections();
          if (expandedHere > 0) {
            log(`Screenshot: chunk ${chunks.length + 1} — expanded ${expandedHere} newly-visible inline section(s)`);
          }
          // Tail of the original 800ms pause, lets the
          // re-rendered DOM settle before we paint.
          await pause(400);

          if (y > 0 && fixedHeaders.length > 0) {
            for (const el of fixedHeaders) {
              el.style.display = "none";
            }
          }

          try {
            const dataURL = await captureViewportPNG();
            // Use the ACTUAL scroll position from scrollToY,
            // not the requested `y` — when the inner container
            // is the real scroller and reports its own scrollTop,
            // stitching at the requested `y` would put chunks
            // at wrong canvas positions. `scrollResult.y` is
            // what the visible viewport is actually showing.
            chunks.push({ y: scrollResult.y, dataURL });
          } catch (captureErr) {
            console.warn(`[AMCRM] Screenshot chunk ${chunks.length + 1} at y=${y} failed:`, captureErr);
            // Continue rather than abort — a partial stitch is
            // more useful than nothing. If captureVisibleTab is
            // throttled we get a transient failure; the next
            // chunk might succeed.
          }

          // Re-measure AFTER capture — lazy-loaded sections may
          // have rendered while we paused, growing the document
          // beyond what we saw at iteration start.
          const currentHeight = measureScrollHeight();
          log(`Screenshot: chunk ${chunks.length} requested y=${y}, actual y=${scrollResult.y} (via=${scrollResult.via}), height now ${currentHeight}, lastHeight ${lastHeight}`);

          // **Scroll-stuck termination.** If the scroll didn't
          // move (we requested y > 0 but actual y is still 0,
          // or actual didn't budge from the previous chunk's
          // actual), don't loop forever capturing the same
          // viewport. Stop and stitch what we have.
          if (y > 0 && scrollResult.via.includes("stuck")) {
            log(`Screenshot: scroll stuck at y=${scrollResult.y}; stopping after ${chunks.length} chunk(s) to avoid same-page repeats.`);
            break;
          }

          // Termination check: we've reached the bottom AND the
          // height stopped growing for two consecutive scrolls
          // (defense against a single-tick lazy-load).
          const reachedBottom = y + viewportH >= currentHeight;
          const heightStable = Math.abs(currentHeight - lastHeight) < STABLE_HEIGHT_TOLERANCE;
          if (reachedBottom && heightStable) {
            stableCount += 1;
            if (stableCount >= 2) break;
          } else {
            stableCount = 0;
          }

          lastHeight = currentHeight;
          y += viewportH;
        }

        if (chunks.length === 0) {
          throw new Error("No viewport captures succeeded — captureVisibleTab returned errors on every chunk.");
        }

        // Final height = where we ended up. Each chunk got
        // captured at a specific y; stitch the canvas using
        // those y offsets so partial-failure runs (some chunks
        // missing) still produce a usable image with gaps
        // rather than misaligned pixels.
        const finalHeight = Math.max(measureScrollHeight(), y + viewportH);
        log(`Screenshot: capture complete — ${chunks.length} chunks, final height ${finalHeight}`);

        const canvas = document.createElement("canvas");
        canvas.width = viewportW * dpr;
        canvas.height = finalHeight * dpr;
        const ctx = canvas.getContext("2d");
        // Fill background white so transparent chunks (gaps)
        // don't show as black in the resulting PNG.
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        for (const { y: chunkY, dataURL } of chunks) {
          const img = await loadImage(dataURL);
          // captureVisibleTab returns the image at device pixel
          // ratio; drawing at scaled Y keeps the stitched
          // output sharp on retina screens.
          ctx.drawImage(img, 0, chunkY * dpr);
        }

        const blob = await new Promise(resolve => canvas.toBlob(resolve, "image/png"));
        if (!blob) throw new Error("canvas.toBlob returned null");

        const profileName = safeFilename(extractProfileName());
        const filename = `${profileName} — LinkedIn Profile — ${todayStamp()}.png`;
        const url = URL.createObjectURL(blob);
        const anchor = document.createElement("a");
        anchor.href = url;
        anchor.download = filename;
        anchor.style.display = "none";
        document.body.appendChild(anchor);
        anchor.click();
        document.body.removeChild(anchor);
        setTimeout(() => URL.revokeObjectURL(url), 5_000);

        log(`Screenshot: downloaded ${filename} (${chunks.length} chunks, ${finalHeight}px tall, ${blob.size} bytes)`);
        return filename;
      } finally {
        for (let i = 0; i < fixedHeaders.length; i++) {
          fixedHeaders[i].style.display = originalDisplay[i];
        }
        // Restore the walker overlay we hid before capture.
        if (walkerOverlay) {
          walkerOverlay.style.display = walkerOverlayOriginalDisplay || "";
        }
        window.scrollTo(0, originalScroll);
      }
    }

    return { captureFullProfileScreenshot };
  })();

  // Message listener for popup-triggered captures. The popup
  // sends `{ type: "capture-profile" }` after the user taps the
  // "Capture this profile" button.
  browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || message.type !== "capture-profile") return;
    SCREENSHOT.captureFullProfileScreenshot()
      .then(filename => sendResponse({ ok: true, filename }))
      .catch(err => {
        console.error("[AMCRM] capture-profile failed:", err);
        sendResponse({ ok: false, error: String(err && err.message ? err.message : err) });
      });
    return true; // keep the channel open for the async response
  });

  // =========================================================
  // Send-Follow-up auto-fill — Sales Navigator ONLY (human-in-the-loop)
  // =========================================================
  //
  // The macOS app's "Send LinkedIn Follow-up" button hands off the
  // drafted InMail for a Sales Nav lead by base64-encoding a JSON
  // `{ v, urn, name, text }` into `?amcrm_send_text=<b64>` on the
  // lead's `/sales/lead/{URN}` URL and opening Safari there. This
  // block picks the param up on landing (top frame, `/sales/` only),
  // clicks the lead's Message button, waits for the InMail composer
  // LinkedIn opens in response, VERIFIES it belongs to the handed-off
  // lead (page-URN + recipient-name match), then types the subject +
  // body and stops with the composer in focus.
  //
  // **Sales Nav is the only surface this runs on.** Regular `/in/`
  // DMs use LinkedIn's native `messaging/compose/?recipient=&body=`
  // prefill (no extension). **Send is always the user's job — we
  // NEVER click LinkedIn's Send button programmatically**, and if any
  // safety check fails we type nothing at all. See `tick()` for the
  // full guardrail list and feedback_linkedin_send.md for the three
  // prior misfires these guards exist to prevent.

  const SEND_FOLLOWUP = (() => {
    const STORAGE_TEXT = "amcrm_send_text";

    /// Selector pool for LinkedIn's profile-level "Message" button.
    /// Restricts to `main` so the top-bar navigation Messaging icon
    /// doesn't match — we want the per-profile action button.
    const MESSAGE_BUTTON_SELECTORS = [
      'main button[aria-label*="Message" i]',
      'main a[aria-label*="Message" i]',
      // Some profile layouts ship the Message CTA inside an
      // action-bar wrapper with a more specific aria-label.
      'main [aria-label^="Message " i]',
      'main button[aria-label$=" Message" i]'
    ];

    /// Sales Nav InMail has a dedicated Subject input above the
    /// body composer. The pool below covers the variants seen in
    /// the v2 / v3 layouts of the Sales Nav messaging surface.
    /// Regular LinkedIn DM doesn't have this field so the
    /// finder returns null on `/in/{slug}` pages — that path
    /// just falls back to body-only fill.
    const SUBJECT_INPUT_SELECTORS = [
      'input[aria-label*="Subject" i]',
      'input[placeholder*="Subject" i]',
      'input[name*="subject" i]',
      'input[id*="subject" i]',
      '.compose-form__subject input',
      '.send-as-message-form__subject input',
      'form[role="form"] input[type="text"]:first-of-type'
    ];

    /// LinkedIn's message composer uses a contenteditable div
    /// (TipTap/ProseMirror-style), not a textarea. The pool below
    /// covers both surfaces:
    ///   - Regular LinkedIn DM on `/in/{slug}` — the overlay
    ///     composer that slides in from the bottom-right (the
    ///     `msg-overlay-*` and `msg-form-*` class families).
    ///   - Sales Navigator InMail on `/sales/lead/{URN}` — a
    ///     modal-style composer with `artdeco-modal` /
    ///     `artdeco-message-input` containers.
    ///
    /// The aria-label / role / placeholder-based entries are
    /// surface-agnostic and try first; the class-based fallbacks
    /// cover layouts where LinkedIn has obfuscated the durable
    /// hints. `findComposer` filters all matches for visibility
    /// before returning so a hidden composer from the other
    /// surface doesn't get clicked.
    const COMPOSER_SELECTORS = [
      // Sales Nav InMail body — a plain <textarea>, NOT a
      // contenteditable (verified live 2026: name="message",
      // placeholder/aria "Type your message here…"). Listed first so
      // the InMail surface is matched before the DM contenteditable.
      'textarea[name="message"]',
      'textarea[aria-label*="message" i]',
      'textarea[placeholder*="message" i]',
      // Surface-agnostic (most durable) — aria / role / placeholder.
      'div[contenteditable="true"][role="textbox"][aria-label*="message" i]',
      'div[contenteditable="true"][aria-label*="Write a message" i]',
      'div[contenteditable="true"][aria-label*="Write your message" i]',
      'div[contenteditable="true"][data-placeholder*="message" i]',
      // Regular LinkedIn DM composer class families.
      'div.msg-form__contenteditable[contenteditable="true"]',
      '.msg-overlay-conversation-bubble div[contenteditable="true"]',
      '.msg-form__msg-content-container div[contenteditable="true"]',
      // Sales Nav InMail composer class families.
      '.artdeco-message-input div[contenteditable="true"]',
      '.send-as-message-form div[contenteditable="true"]',
      '.message-composer div[contenteditable="true"]',
      // Final fallback: any visible contenteditable inside a
      // modal or role=dialog container, which is the shape both
      // surfaces' overlay composers settle into.
      '.artdeco-modal div[contenteditable="true"]',
      '[role="dialog"] div[contenteditable="true"]'
    ];

    let overlayEl = null;

    /// Local poll helper — the walker defines its own `wait` inside a
    /// sibling IIFE, which isn't in scope here. The finders below
    /// (`findMessageButton`, `findComposer`, `findSubjectInput`) call
    /// this between DOM polls.
    function wait(ms) {
      return new Promise(resolve => setTimeout(resolve, ms));
    }

    /// Reads the one-shot handoff the macOS app appends to the Sales
    /// Nav lead URL: `?amcrm_send_text=<base64(JSON)>`, where the JSON
    /// is `{ v, urn, name, text }`. `urn` + `name` drive the safety
    /// checks in `run`; `text` is the drafted InMail (a leading
    /// `Subject: …` line splits into the subject field). Strips the
    /// param immediately — unconditionally, even on a malformed
    /// payload — so a manual reload can NEVER re-fire the fill, then
    /// returns the parsed payload (or null). We deliberately do NOT
    /// persist to storage: the fill only ever runs on the exact
    /// navigation the app initiated, never a later visit to the lead.
    async function maybeBootstrap() {
      const url = new URL(location.href);
      const encoded = url.searchParams.get("amcrm_send_text");
      if (!encoded) return null;
      url.searchParams.delete("amcrm_send_text");
      history.replaceState({}, "", url.toString());
      try {
        const json = decodeURIComponent(escape(atob(encoded)));
        const payload = JSON.parse(json);
        if (payload && typeof payload.text === "string" && payload.text.trim()) {
          log(`Send-followup handoff: ${payload.text.length} chars for ${payload.name || "lead"}.`);
          return payload;
        }
        return null;
      } catch (err) {
        console.error("[AMCRM send-followup] bootstrap decode failed:", err);
        return null;
      }
    }

    async function readPendingText() {
      const res = await browser.storage.local.get(STORAGE_TEXT);
      return res[STORAGE_TEXT] || null;
    }

    async function clearPending() {
      await browser.storage.local.remove(STORAGE_TEXT);
    }

    /// Poll the DOM for a visible Message button. Three tiers:
    ///   1. `main`-scoped aria-label match (most reliable — works
    ///      on regular profile pages where the action bar lives
    ///      inside `<main>`).
    ///   2. `main`-scoped text-content "Message" (same scope; for
    ///      layouts that ship without an aria-label).
    ///   3. Body-wide aria-label match with an exclusion filter
    ///      for the top-bar Messaging navigation entry. Sales Nav
    ///      lead pages sometimes render the action bar OUTSIDE
    ///      the `<main>` element, so the main-scoped selectors
    ///      miss; the body-wide pass catches that while the
    ///      filter keeps us off the global Messaging nav button.
    async function findMessageButton(timeout = 15_000) {
      const deadline = Date.now() + timeout;
      while (Date.now() < deadline) {
        // 1. main-scoped aria-label match.
        for (const sel of MESSAGE_BUTTON_SELECTORS) {
          for (const el of document.querySelectorAll(sel)) {
            if (isVisibleEl(el)) return el;
          }
        }
        // 2. main-scoped text-content match.
        for (const el of document.querySelectorAll("main button, main a")) {
          if (!isVisibleEl(el)) continue;
          const text = (el.textContent || "").trim();
          if (text === "Message") return el;
        }
        // 3. Body-wide aria-label match with an exclusion list
        //    for the top-bar Messaging navigation entry.
        for (const el of document.querySelectorAll('button[aria-label*="Message" i], a[aria-label*="Message" i]')) {
          if (!isVisibleEl(el)) continue;
          const aria = (el.getAttribute("aria-label") || "").toLowerCase();
          // Skip the global Messaging nav button — it has labels
          // like "Messaging", "Open Messaging", or "Messaging
          // overlay" rather than the per-profile "Message" CTA.
          if (aria === "messaging") continue;
          if (aria.startsWith("messaging ")) continue;
          if (aria.includes("open messaging")) continue;
          if (aria.includes("messaging overlay")) continue;
          if (aria.includes("messaging panel")) continue;
          return el;
        }
        await wait(300);
      }
      return null;
    }

    /// Returns the set of every visible composer on the page right
    /// now. Used as a "before" snapshot so `findComposer` can
    /// identify the one that LinkedIn JUST opened in response to a
    /// Message-button click, rather than picking a stale floating
    /// "New message" panel that was already open for an unrelated
    /// lead (e.g. a Dawn Kallevig draft the user hadn't sent yet).
    function snapshotVisibleComposers() {
      const seen = new Set();
      for (const sel of COMPOSER_SELECTORS) {
        for (const el of document.querySelectorAll(sel)) {
          if (isVisibleEl(el)) seen.add(el);
        }
      }
      return seen;
    }

    /// Polls for a composer that wasn't in `existing` — the one
    /// that just appeared as a result of clicking the profile's
    /// Message button. Falls back to the first visible composer
    /// only after the diff scan has timed out; on that fallback
    /// we still prefer composers whose closest ancestor with an
    /// `aria-label` hints at the right lead's name, but the
    /// diff-based detection is the primary path.
    async function findComposer(timeout = 15_000, existing = new Set()) {
      const deadline = Date.now() + timeout;
      while (Date.now() < deadline) {
        for (const sel of COMPOSER_SELECTORS) {
          for (const el of document.querySelectorAll(sel)) {
            if (!isVisibleEl(el)) continue;
            if (existing.has(el)) continue;
            return el;
          }
        }
        await wait(300);
      }
      // Diff timed out — every visible composer was already open
      // before we clicked Message. Bail rather than fill the wrong
      // one. Caller surfaces a "composer didn't open" error so
      // Adam knows to close the stale floating panels and retry.
      return null;
    }

    /// Confirms the just-opened composer actually belongs to the lead
    /// the app handed off, by looking for the recipient's name in the
    /// composer's enclosing modal / overlay. This is the guard the
    /// diff-snapshot alone couldn't provide: if a stale composer for a
    /// DIFFERENT lead is what ended up visible, its header won't carry
    /// our recipient's name and we ABORT rather than type into the
    /// wrong person's message box (the exact v0.1.166 failure mode).
    /// Returns true only on a positive match; when the name genuinely
    /// can't be located we return false and the caller skips the fill —
    /// "abort when unsure" is the whole point of this function.
    function composerMatchesRecipient(composer, expectedName) {
      const name = (expectedName || "").trim().toLowerCase();
      if (!name) return false;               // no name to verify against → don't guess
      const tokens = name.split(/\s+/).filter(t => t.length > 1);
      const nameIn = (s) => {
        s = (s || "").toLowerCase();
        if (!s) return false;
        if (s.includes(name)) return true;
        // First + last tokens both present (covers a credential / middle
        // name rendered between them, or nodes split apart).
        if (tokens.length >= 2) return s.includes(tokens[0]) && s.includes(tokens[tokens.length - 1]);
        return tokens.length === 1 ? s.includes(tokens[0]) : false;
      };
      // 1. Known overlay / modal / conversation container — scoped, so
      //    a hit here is a strong "this composer belongs to that lead."
      const overlay = composer.closest(
        '.msg-overlay-conversation-bubble, .artdeco-modal, [role="dialog"], ' +
        '[class*="msg-overlay"], [class*="message-overlay"], [class*="conversation"]'
      );
      if (overlay && nameIn(overlay.textContent)) return true;
      // 2. Bounded upward walk — climb until an ancestor carries the
      //    name, but STOP before the subtree balloons to page size. The
      //    lead's own profile page contains their name all over, so an
      //    unbounded walk would always "match" and defeat the guard; the
      //    InMail overlay is a few-thousand chars at most.
      let node = composer;
      for (let i = 0; i < 14 && node; i++) {
        if (node.tagName === "MAIN" || node.tagName === "BODY") break;
        const txt = node.textContent || "";
        if (txt.length > 12_000) break;
        if (nameIn(txt)) return true;
        node = node.parentElement;
      }
      return false;
    }

    /// Finds the InMail / DM composer that belongs to `name`, polling
    /// until it appears. Unlike the old before/after diff (which
    /// silently failed whenever a composer was ALREADY open — e.g. a
    /// stale panel from a prior attempt), this matches by recipient:
    /// among every visible composer it returns the first whose overlay
    /// carries the lead's name. That both LOCATES the composer AND
    /// verifies it's the right lead's, so a stale composer for someone
    /// else is never filled. Returns null on timeout (caller aborts).
    async function findComposerForRecipient(name, timeout = 15_000) {
      const want = (name || "").trim();
      const deadline = Date.now() + timeout;
      while (Date.now() < deadline) {
        for (const sel of COMPOSER_SELECTORS) {
          for (const el of document.querySelectorAll(sel)) {
            if (!isVisibleEl(el)) continue;
            if (!want || composerMatchesRecipient(el, want)) return el;
          }
        }
        await wait(300);
      }
      return null;
    }

    /// Locates the Subject input, preferring the one inside the same
    /// compose form as `composer` so multiple open overlays don't cross
    /// wires. Falls back to a page-wide scan.
    function findSubjectInputNear(composer) {
      const scope = composer.closest('form, [class*="compose"], [class*="msg-form"], .artdeco-modal, [role="dialog"]');
      for (const root of [scope, document]) {
        if (!root) continue;
        for (const sel of SUBJECT_INPUT_SELECTORS) {
          for (const el of root.querySelectorAll(sel)) {
            if (isVisibleEl(el) && (el.tagName === "INPUT" || el.tagName === "TEXTAREA")) return el;
          }
        }
      }
      return null;
    }

    /// Fills either surface: a <textarea>/<input> gets the native-setter
    /// treatment (React needs the input/change events); a contenteditable
    /// div goes through the execCommand path.
    function fillField(el, text) {
      if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") {
        fillNativeInput(el, text);
      } else {
        fillComposer(el, text);
      }
    }

    /// Polls for Sales Nav's Subject input on the InMail composer
    /// surface. Shorter timeout than `findComposer` because we
    /// only call this after the composer is already visible, so
    /// the subject field — if it exists — should be in the same
    /// render pass. Returns null on regular LinkedIn DM where no
    /// subject field exists; caller treats that as "fall back to
    /// body-only fill."
    async function findSubjectInput(timeout = 4_000) {
      const deadline = Date.now() + timeout;
      while (Date.now() < deadline) {
        for (const sel of SUBJECT_INPUT_SELECTORS) {
          for (const el of document.querySelectorAll(sel)) {
            if (isVisibleEl(el) && (el.tagName === "INPUT" || el.tagName === "TEXTAREA")) {
              return el;
            }
          }
        }
        await wait(250);
      }
      return null;
    }

    /// Splits a draft text into Subject + body when the first
    /// line starts with `Subject: …`. Returns `{ subject, body }`.
    /// When no Subject prefix is present, returns
    /// `{ subject: null, body: <whole text> }` so the caller
    /// falls back to body-only fill.
    function splitDraftBySubject(text) {
      const trimmed = (text || "").replace(/^﻿/, "");
      const match = trimmed.match(/^Subject:\s*([^\n]*)\n\s*\n?([\s\S]*)$/i);
      if (!match) return { subject: null, body: trimmed };
      const subject = (match[1] || "").trim();
      const body = (match[2] || "").trimStart();
      if (!subject) return { subject: null, body: trimmed };
      return { subject, body };
    }

    /// Drops `text` into a plain `<input>` / `<textarea>` AND
    /// fires the events React needs to recognise the value. A
    /// raw `el.value = ...` assignment doesn't trigger React's
    /// state update on its own; we have to dispatch `input` (and
    /// `change` for safety) after setting the value via the
    /// native setter so React's onChange handler picks it up.
    function fillNativeInput(el, text) {
      const prototype = el instanceof HTMLTextAreaElement
        ? HTMLTextAreaElement.prototype
        : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(prototype, "value").set;
      setter.call(el, text);
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    }

    function isVisibleEl(el) {
      if (!(el instanceof HTMLElement)) return false;
      if (el.offsetParent === null) return false;
      const rect = el.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    }

    /// Insert `text` into a contenteditable. LinkedIn's React layer
    /// listens for `input` events on the composer to enable the
    /// Send button — setting `.innerHTML` alone won't flip the
    /// state, so we use `document.execCommand('insertText', ...)`
    /// which fires a synthetic InputEvent automatically. Falls
    /// back to manual innerHTML + InputEvent dispatch when
    /// execCommand returns false (some Safari builds reject it on
    /// contenteditable that isn't already focused).
    function fillComposer(el, text) {
      el.focus();
      // Clear any existing content first so re-runs don't append.
      const range = document.createRange();
      range.selectNodeContents(el);
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
      try {
        const ok = document.execCommand("insertText", false, text);
        if (ok) return true;
      } catch (_) { /* fall through */ }
      // Fallback path — wrap each newline-separated chunk in a
      // <p> tag so LinkedIn renders the breaks. ProseMirror will
      // re-parse on the input event.
      const html = text.split("\n").map(line => {
        const safe = line.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
        return `<p>${safe || "<br>"}</p>`;
      }).join("");
      el.innerHTML = html;
      el.dispatchEvent(new InputEvent("input", {
        bubbles: true,
        cancelable: true,
        inputType: "insertText",
        data: text
      }));
      return true;
    }

    function debugDumpMessageButtons() {
      const buttons = Array.from(document.querySelectorAll("main button, main a"));
      const candidates = buttons
        .filter(b => b instanceof HTMLElement && b.offsetParent !== null)
        .filter(b => {
          const a = (b.getAttribute("aria-label") || "").toLowerCase();
          const t = (b.textContent || "").toLowerCase();
          return a.includes("message") || t.includes("message");
        })
        .slice(0, 10)
        .map(b => ({
          tag: b.tagName.toLowerCase(),
          aria: b.getAttribute("aria-label") || "(none)",
          text: (b.textContent || "").trim().slice(0, 40) || "(empty)",
          classes: (b.className || "").split(/\s+/).slice(0, 3).join(" ")
        }));
      console.warn("[AMCRM send-followup] Message button not found. Candidates:", candidates);
    }

    function debugDumpComposers() {
      // Dump BOTH textareas and contenteditables — Sales Nav InMail uses
      // a <textarea>, regular DM a contenteditable div.
      const els = Array.from(document.querySelectorAll('textarea, [contenteditable="true"]'));
      const candidates = els
        .filter(e => e instanceof HTMLElement && e.offsetParent !== null)
        .slice(0, 10)
        .map(e => ({
          tag: e.tagName.toLowerCase(),
          name: e.getAttribute("name") || "(none)",
          aria: e.getAttribute("aria-label") || "(none)",
          placeholder: e.getAttribute("placeholder") || e.getAttribute("data-placeholder") || "(none)",
          role: e.getAttribute("role") || "(none)",
          classes: (e.className || "").split(/\s+/).slice(0, 3).join(" ")
        }));
      console.warn("[AMCRM send-followup] Composer not matched. Visible textareas + contenteditables:", candidates);
    }

    function renderOverlay({ status, error, ready }) {
      if (overlayEl) overlayEl.remove();
      overlayEl = document.createElement("div");
      overlayEl.id = "amcrm-send-overlay";
      Object.assign(overlayEl.style, {
        position: "fixed",
        right: "18px",
        bottom: "18px",
        zIndex: "2147483647",
        background: error ? "rgba(127,29,29,0.95)" : "rgba(15,23,42,0.95)",
        color: "#fff",
        padding: "12px 14px",
        borderRadius: "10px",
        boxShadow: "0 10px 30px rgba(0,0,0,0.35)",
        fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
        fontSize: "13px",
        lineHeight: "1.4",
        maxWidth: "320px"
      });
      const title = error
        ? "Follow-up flow stalled"
        : ready
          ? "Draft ready on your clipboard"
          : "Loading follow-up draft…";
      // Body: error wins everything. Otherwise a caller-supplied
      // `status` overrides the ready-state default — lets the
      // tick() flow swap in "Composer is open, paste with ⌘V"
      // vs "Click Message yourself" depending on whether the
      // auto-open succeeded.
      const body = error
        ? error + " — see Safari console for details."
        : status
          ? status
          : ready
            ? "Click the profile's Message button to open the composer, then press ⌘V to paste the draft. Review and send when ready."
            : "";
      overlayEl.innerHTML = `
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;">
          <div style="font-weight:600;">${title}</div>
          <div style="flex:1;"></div>
          <button id="amcrm-send-dismiss"
            style="background:transparent;border:1px solid rgba(255,255,255,0.4);color:#fff;font-size:11px;padding:2px 8px;border-radius:6px;cursor:pointer;">
            Dismiss
          </button>
        </div>
        <div style="opacity:0.85;font-size:12px;">${body}</div>
      `;
      document.body.appendChild(overlayEl);
      overlayEl.querySelector("#amcrm-send-dismiss").addEventListener("click", () => {
        overlayEl.remove();
        overlayEl = null;
      });
    }

    async function tick() {
      // Sales-Navigator-ONLY auto-fill. content.js also runs on
      // `/in/*`, but the send-fill path is deliberately scoped to the
      // `/sales/` InMail surface — the one place LinkedIn exposes no
      // compose-with-body deep-link, so the app has no native prefill
      // to fall back on. Regular `/in/` DMs use LinkedIn's own
      // `messaging/compose/?recipient=&body=` prefill and never reach
      // this code.
      //
      // History (see feedback_linkedin_send.md): three prior attempts
      // hijacked the WRONG composer — v0.1.107 (Dawn Kallevig),
      // v0.1.157, v0.1.166 (diff-snapshot still filled a stale overlay).
      // The guardrails below exist specifically to prevent a repeat:
      //   1. top frame only (all_frames injection would double-fire),
      //   2. `/sales/` path only,
      //   3. one-shot param, stripped before we act (no reload re-fire),
      //   4. page-URN must match the handoff,
      //   5. the composer is located BY RECIPIENT NAME (its overlay must
      //      carry the lead's name) — this both finds it and rejects a
      //      stale composer for anyone else. Nothing is typed unless a
      //      recipient-matched composer is found.
      // If any check is unmet we ABORT and type nothing. We NEVER
      // click LinkedIn's Send button — that stays a human action.
      if (window.top !== window.self) return;               // (1) top frame only
      if (!location.pathname.startsWith("/sales/")) return; // (2) Sales Nav only

      const payload = await maybeBootstrap();               // (3) reads + strips the param
      if (!payload) return;                                 // no fresh handoff → no-op

      // (4) Page-identity guard: we must be on the exact lead the app
      // handed off. The app opens `/sales/lead/{urn}?...`, so this
      // holds by construction; the check defends against any future
      // caller that navigates differently, and against a decoded-but-
      // mismatched payload.
      if (payload.urn && !location.href.includes(payload.urn)) {
        log(`Send-followup: page doesn't match handoff URN (${payload.urn}); skipping.`);
        return;
      }

      await run(payload);
    }

    /// Clicks Message, waits for the composer LinkedIn opens in
    /// response (diff against the pre-click snapshot), verifies it
    /// belongs to the handed-off lead, then types subject + body.
    /// Every failure path renders an overlay and returns WITHOUT
    /// typing — the wrong-composer cases must fail closed.
    async function run(payload) {
      renderOverlay({ status: `Opening the InMail composer for ${payload.name || "this lead"}…` });
      try {
        const btn = await findMessageButton();
        if (!btn) {
          debugDumpMessageButtons();
          renderOverlay({ error: "Couldn't find this lead's Message button" });
          return;
        }
        btn.click();
        // (5)+(6) Locate the composer BY RECIPIENT — this both finds it
        // (textarea InMail body or contenteditable DM) and verifies it
        // belongs to the handed-off lead, so a stale composer for
        // someone else is never filled. Handles already-open composers
        // (the old before/after diff couldn't). Null → abort, fail closed.
        const composer = await findComposerForRecipient(payload.name, 15_000);
        if (!composer) {
          debugDumpComposers();
          renderOverlay({ error: `Couldn't find ${payload.name || "this lead"}'s InMail composer — close any stale message panels, then press Send LinkedIn Follow-up again. If the composer is open and correct, paste with ⌘V.` });
          return;
        }
        const { subject, body } = splitDraftBySubject(payload.text);
        if (subject) {
          const subjectInput = findSubjectInputNear(composer) || await findSubjectInput();
          if (subjectInput) fillNativeInput(subjectInput, subject);
        }
        fillField(composer, body);
        renderOverlay({
          ready: true,
          status: `Draft filled for ${payload.name || "this lead"}. Review the recipient and message, then click Send yourself.`
        });
        log(`Send-followup: filled composer for ${payload.name || "lead"} (${body.length} chars${subject ? " + subject" : ""}).`);
      } catch (err) {
        console.error("[AMCRM send-followup] run failed:", err);
        renderOverlay({ error: String(err && err.message ? err.message : err) });
      }
    }

    return { tick, run };
  })();

  SEND_FOLLOWUP.tick().catch(err => console.error("[AMCRM send-followup tick]", err));

  // ---------------- card detection ----------------

  // Try these selectors first — covers every Sales Nav search /
  // list / lead-detail layout we've seen. If none of these match,
  // we fall through to a generic "walk up from profile link"
  // strategy which is far more durable across DOM rewrites.
  const SALESNAV_CARD_SELECTORS = [
    '[data-x-search-result="LEAD"]',
    "[data-x-search-result-id]",
    "li.artdeco-list__item.search-results__result-item",
    "li.search-results__result-item",
    "li[data-x-search-result]",
    "li.result-lockup",
    "li.artdeco-list__item",
    "div.result-lockup",
    "article.search-result",
    "tr[data-x-search-result]"
  ];

  // Marketplace request cards. LinkedIn actually exposes
  // `data-test-service-marketplace-{premium,direct}-service-
  // requests__list-item` attributes on the `<li>` rows of the
  // Provider → Requests page — far more durable than guessing at
  // class names. The class-based selectors below remain as
  // fallbacks for any future surface where the test attribute
  // gets renamed.
  const MARKETPLACE_CARD_SELECTORS = [
    "li[data-test-service-marketplace-premium-service-requests__list-item]",
    "li[data-test-service-marketplace-direct-service-requests__list-item]",
    "li.service-marketplace-provider-requests__service-requests-list-item",
    '[data-test-id="service-request-card"]',
    '[data-test-id="provider-request-card"]',
    "div.service-request-card",
    "article.service-request",
    "[data-test-marketplace-request]"
  ];

  const CARD_SELECTORS = SURFACE === "marketplace"
    ? MARKETPLACE_CARD_SELECTORS
    : SALESNAV_CARD_SELECTORS;

  const FIELD_SELECTORS = {
    nameLink: [
      'a[data-anonymize="person-name"]',
      'a[href*="/sales/lead/"]',
      'a[href*="/sales/people/"]',
      'a[href*="/in/"]',
      ".artdeco-entity-lockup__title a",
      ".result-lockup__name a",
      "[data-control-name='view_lead_panel_via_search_lead_name']"
    ],
    headline: [
      '[data-anonymize="job-title"]',
      ".artdeco-entity-lockup__subtitle",
      ".result-lockup__highlight-keyword",
      ".search-result__info .subtitle",
      ".result-lockup__position-company"
    ],
    location: [
      '[data-anonymize="location"]',
      ".artdeco-entity-lockup__caption",
      ".search-result__info .caption",
      ".result-lockup__misc-item"
    ],
    company: [
      '[data-anonymize="company-name"]',
      ".result-lockup__highlight-keyword",
      ".result-lockup__position-company a"
    ],
    /// The card's "About" blurb — the multi-line bio Sales Nav
    /// shows before the "Show more" truncation. Highest-signal
    /// extra field; feeds the AI's first-touch personalization.
    about: [
      '[data-anonymize="person-blurb"]',
      ".entity-result__summary",
      ".about-section",
      ".result-lockup__details p",
      "p.about-text"
    ],
    /// Tenure summary like "7 months in role | 7 months in
    /// company". Helps the AI gauge career stage.
    tenure: [
      '[data-test-id="tenure"]',
      ".tenure-info",
      ".result-context__time"
    ],
    /// Public LinkedIn profile link — when present, replaces the
    /// Sales Nav detail URL as the canonical identity. Usually
    /// behind a "View on LinkedIn" overflow item, but sometimes
    /// available as a direct anchor inside the card chrome.
    publicProfileLink: [
      'a[href*="linkedin.com/in/"]',
      'a[href^="/in/"]',
      "[data-control-name='view_linkedin_profile']"
    ],
    /// Marketplace-only: the service name the requester asked
    /// about (e.g. "Resume Writing", "Career Coaching"). Often
    /// the card heading or first-line label.
    serviceRequested: [
      '[data-test-id="service-name"]',
      '[data-test-id="request-service"]',
      ".service-name",
      ".request-service-type",
      "h2",
      "h3"
    ],
    /// Marketplace-only: the project description / message the
    /// requester wrote.
    projectDetails: [
      '[data-test-id="message"]',
      '[data-test-id="request-message"]',
      '[data-test-id="project-description"]',
      ".request-message",
      ".project-description",
      ".message-text"
    ],
    /// Marketplace list-item creator name. The visible text lives
    /// inside `<span aria-hidden="true">…</span>` — we prefer that
    /// child explicitly so we don't double up with the sibling
    /// `<span class="visually-hidden">…</span>` LinkedIn renders
    /// for screen readers.
    marketplaceCreatorName: [
      '[data-test-service-requests-list-item__creator-name] span[aria-hidden="true"]',
      '[data-test-service-requests-list-item__creator-name]'
    ],
    /// Marketplace list-item project title — the service the
    /// requester is asking about (e.g. "Resume Review"). Lives
    /// in the same aria-hidden/visually-hidden span pair pattern
    /// as the creator name.
    marketplaceProjectTitle: [
      '[data-test-service-requests-list-item__project-title] span[aria-hidden="true"]',
      '[data-test-service-requests-list-item__project-title]'
    ],
    /// Marketplace creator profile image — used as a name fallback
    /// when the name span text is unexpectedly empty. The `alt`
    /// attribute reads "Kevin Jones is open to work" / "Kevin
    /// Jones, graphic" — we strip the suffixes.
    marketplaceCreatorImage: [
      '[data-test-service-requests-list-item__creator-profile-image] img'
    ]
  };

  function pick(card, sels) {
    for (const sel of sels) {
      const el = card.querySelector(sel);
      if (el) return el;
    }
    return null;
  }

  function text(el) {
    return el ? (el.innerText || el.textContent || "").trim() : "";
  }

  /// Strips LinkedIn's "last active" / "online now" suffixes
  /// that some Sales Nav card layouts splice onto the name
  /// string. Without this, the importer ends up with last names
  /// like "Chen - was last active 3 days ago" because the
  /// extension's first/last split treats every space-delimited
  /// token after the first as part of the last name.
  ///
  /// Catches the variants we've seen:
  ///   - "Sarah Chen - was last active 3 days ago"
  ///   - "Sarah Chen · was last active 5 minutes ago"
  ///   - "Sarah Chen — last active 2h ago"
  ///   - "Sarah Chen - active recently"
  ///   - "Sarah Chen · online now"
  ///
  /// Also handles the leading "Status is online", "(He/Him)",
  /// "(She/Her)" pronoun parentheticals and the trailing
  /// "is open to work" / "is hiring" pattern badges that get
  /// pulled in via aria-label fallbacks.
  function cleanProfileName(raw) {
    if (!raw) return "";
    let s = String(raw).trim();
    // Strip trailing "[- · — –] [was] [last] active/online …".
    s = s.replace(
      /\s*[-·–—]\s*(?:was\s+)?(?:last\s+)?(?:active|online)\b[\s\S]*$/i,
      ""
    );
    // Strip trailing "is open to work" / "is hiring" / "open to
    // work" badge text — same root cause, different signal.
    s = s.replace(
      /\s*(?:is\s+)?(?:open\s+to\s+work|hiring|open_to_work|provides services as a)\b[\s\S]*$/i,
      ""
    );
    // Strip the leading "Status is online, " / "Status is
    // reachable, " etc. that LinkedIn prepends to some aria
    // labels.
    s = s.replace(/^Status\s+is\s+\w+[,\s]+/i, "");
    // Strip pronoun parentheticals like "(He/Him)", "(She/Her)",
    // "(They/Them)" — useful info for the AI but not part of
    // the legal name.
    s = s.replace(/\s*\((?:he|she|they|him|her|them|xe|ze|hir)\s*\/[^)]*\)\s*/gi, " ");
    // Collapse any double spaces left behind.
    s = s.replace(/\s{2,}/g, " ").trim();
    return s;
  }

  /// Deep `querySelectorAll` that descends into open shadow roots.
  /// Sales Navigator embeds some result chrome inside web
  /// components, and a plain `document.querySelectorAll` stops at
  /// the shadow boundary. We pay one full DOM walk for the visit
  /// but cache nothing — the cost only matters on a missing scan,
  /// where speed is moot.
  function queryDeep(selector, root) {
    root = root || document;
    const out = [];
    const visit = (node) => {
      try {
        out.push(...node.querySelectorAll(selector));
      } catch { /* invalid scope, skip */ }
      const all = node.querySelectorAll("*");
      for (const el of all) {
        if (el.shadowRoot) visit(el.shadowRoot);
      }
    };
    visit(root);
    return out;
  }

  /// Returns the cards we should attach a Capture button to.
  /// Two strategies, in order:
  ///   1. Known selector pool — fast and precise when LinkedIn's
  ///      markup matches what we've seen before.
  ///   2. Walk up from every profile link to the nearest card-
  ///      shaped DOM container — slower but DOM-rewrite-proof.
  function getCards() {
    for (const sel of CARD_SELECTORS) {
      const els = queryDeep(sel);
      if (els.length) {
        log(`Found ${els.length} cards via selector: ${sel}`);
        return els;
      }
    }

    // Fallback — link-walk strategy. queryDeep so we catch links
    // rendered inside web components / shadow roots.
    const links = queryDeep(
      'a[href*="/sales/lead/"], a[href*="/sales/people/"], a[href*="/in/"]'
    );
    if (links.length === 0) {
      log("No cards found and no profile links on the page either.");
      return [];
    }
    const seen = new Set();
    const cards = [];
    for (const link of links) {
      let node = link;
      for (let i = 0; i < 10; i++) {
        node = node.parentElement;
        if (!node) break;
        const rect = node.getBoundingClientRect();
        // Card-sized: wide enough to hold a real result row,
        // tall enough to be more than a single inline name link,
        // not so tall that we've walked past the card into a
        // page-level container.
        if (rect.width >= 320 && rect.height >= 70 && rect.height <= 500) {
          if (!seen.has(node)) {
            seen.add(node);
            cards.push(node);
          }
          break;
        }
      }
    }
    log(`Fallback found ${cards.length} card-shaped containers from ${links.length} profile links.`);
    return cards;
  }

  /// Marketplace cards have a fundamentally different shape from
  /// Sales Nav: the list `<li>` has no profile link in it, only
  /// a name + service title. The clickable profile URL lives in
  /// the right-pane detail view, which only renders for the
  /// currently-selected card. So Marketplace extraction is
  /// "harvest what's on the row, accept no URL, let dedupeKey
  /// build a synthetic name+service key downstream."
  function extractMarketplaceProfile(card) {
    let name = text(pick(card, FIELD_SELECTORS.marketplaceCreatorName));

    // Name fallback: the profile image `alt` attribute. Reads
    // "Kevin Jones is open to work" on open-to-work profiles and
    // "Kevin Jones, graphic" on closed ones — strip both
    // suffixes plus any trailing comma garbage.
    if (!name) {
      const img = pick(card, FIELD_SELECTORS.marketplaceCreatorImage);
      if (img) {
        const alt = (img.getAttribute("alt") || "").trim();
        name = alt
          .replace(/\s+is\s+open\s+to\s+work\s*$/i, "")
          .replace(/,\s*OPEN_TO_WORK\b.*$/i, "")
          .replace(/,?\s*graphic\s*$/i, "")
          .trim();
      }
    }

    name = cleanProfileName(name);
    const parts = name.split(/\s+/).filter(Boolean);
    const firstName = parts[0] || "";
    const lastName = parts.slice(1).join(" ") || "";

    const serviceRequested = text(
      pick(card, FIELD_SELECTORS.marketplaceProjectTitle)
    );

    return {
      origin: SURFACE,
      firstName,
      lastName,
      linkedInURL: "",
      headline: "",
      title: null,
      company: null,
      location: null,
      industry: null,
      about: null,
      tenure: null,
      publicLinkedInURL: null,
      salesNavURL: null,
      serviceRequested: serviceRequested || null,
      // The project details body only renders in the right-pane
      // detail view (visible for one card at a time), not on the
      // list `<li>` we're harvesting. Stays null at capture time
      // — the host CRM's notes field carries `Service requested:`
      // + the name, which is enough to keep the bulk-capture
      // value high.
      projectDetails: null
    };
  }

  function extractProfile(card) {
    if (SURFACE === "marketplace") return extractMarketplaceProfile(card);
    // First try the curated name-link selector pool. If none
    // match (Sales Nav has at least three card variants in
    // active rotation), fall back to "the first anchor in the
    // card whose href looks like a profile URL" — that's the
    // most durable identity signal even when class names rotate.
    let nameEl = pick(card, FIELD_SELECTORS.nameLink);
    if (!nameEl) {
      nameEl = card.querySelector(
        'a[href*="/sales/lead/"], a[href*="/sales/people/"], a[href*="/in/"]'
      );
    }
    let name = text(nameEl);
    const url = nameEl ? nameEl.href || "" : "";

    // Name fallback: when the link exists but its text is empty
    // (sometimes it wraps an avatar, with the visible name in a
    // sibling element), pull the link's aria-label or
    // `data-anonymize="person-name"` content from anywhere in
    // the card.
    if (!name && nameEl) {
      name = (nameEl.getAttribute("aria-label") || "").trim();
    }
    if (!name) {
      const anyNameEl = card.querySelector('[data-anonymize="person-name"]');
      name = text(anyNameEl);
    }

    // Best-effort first/last split — single-word names land in
    // firstName only. The importer accepts either being empty.
    // Scrub Sales Nav's "last active X ago" / "is open to work"
    // suffixes before splitting so they don't end up in the
    // last name.
    name = cleanProfileName(name);
    const parts = name.split(/\s+/).filter(Boolean);
    const firstName = parts[0] || "";
    const lastName = parts.slice(1).join(" ") || "";

    const headline = text(pick(card, FIELD_SELECTORS.headline));
    const location = text(pick(card, FIELD_SELECTORS.location));
    const companyDirect = text(pick(card, FIELD_SELECTORS.company));
    const about = text(pick(card, FIELD_SELECTORS.about));
    const tenure = text(pick(card, FIELD_SELECTORS.tenure));

    // If we can split "Title at Company" out of the headline,
    // capture title + company as separate fields. Otherwise leave
    // them null and let the headline carry the combined string.
    let title = null;
    let company = companyDirect || null;
    const atMatch = headline.match(/^(.+?)\s+(?:at|@)\s+(.+)$/i);
    if (atMatch) {
      title = atMatch[1].trim();
      if (!company) company = atMatch[2].trim();
    }

    // URL split:
    //   - `url` (from nameEl) is whatever the card's main name
    //     link points at — usually `/sales/lead/…` on Sales Nav.
    //   - publicProfileEl gives the `/in/…` URL when the card
    //     exposes it (some variants put a "View on LinkedIn"
    //     anchor right in the card chrome).
    // Prefer the public URL as `linkedInURL` so the lead record
    // shows the canonical profile rather than a Sales Nav URL
    // that needs a Sales Nav login to open.
    const publicProfileEl = pick(card, FIELD_SELECTORS.publicProfileLink);
    let publicProfileURL = publicProfileEl ? publicProfileEl.href : "";
    // Filter out the name link itself if it pattern-matched
    // `a[href*="/in/"]` (only happens on result variants that
    // actually use the public URL as the card link).
    if (publicProfileURL === url) publicProfileURL = "";
    let salesNavURL = "";
    if (url.includes("/sales/")) {
      salesNavURL = url;
    }
    const canonicalURL = publicProfileURL || url;

    // "About" can include trailing "…Show more" or "…see more"
    // truncation markers — strip those so the AI doesn't read
    // them as part of the bio.
    const cleanedAbout = about
      .replace(/[\s…]*(show more|see more)\s*$/i, "")
      .trim();

    // Marketplace-only fields — only meaningful for service
    // request cards, but extracting them on Sales Nav is a
    // harmless no-op when the selectors don't match.
    const serviceRequested = text(pick(card, FIELD_SELECTORS.serviceRequested));
    const projectDetails = text(pick(card, FIELD_SELECTORS.projectDetails));

    return {
      origin: SURFACE,
      firstName,
      lastName,
      linkedInURL: canonicalURL,
      headline,
      title,
      company,
      location: location || null,
      industry: null,
      about: cleanedAbout || null,
      tenure: tenure || null,
      publicLinkedInURL: publicProfileURL || null,
      salesNavURL: salesNavURL || null,
      serviceRequested: SURFACE === "marketplace" ? (serviceRequested || null) : null,
      projectDetails: SURFACE === "marketplace" ? (projectDetails || null) : null
    };
  }

  // ---------------- marketplace detail-pane scraping ----------------

  /// Find the right-pane detail view on the Marketplace requests
  /// page. Only ever renders for the currently-selected card.
  function getMarketplaceDetailPane() {
    return document.querySelector("#service-marketplace-provider-requests-detail")
        || document.querySelector("[data-test-service-marketplace-service-requests__detail]");
  }

  /// Read the request body, profile URL, headline, location, and
  /// questionnaire Q&A pairs out of the right-pane detail view.
  /// Returns null when the pane isn't rendered.
  function extractMarketplaceDetail() {
    const pane = getMarketplaceDetailPane();
    if (!pane) return null;

    // Name — prefer the aria-hidden visible span to avoid doubling
    // with the visually-hidden screen-reader sibling.
    const nameEl =
      pane.querySelector('[data-test-service-requests-detail__creator-title-link] [aria-hidden="true"]') ||
      pane.querySelector('[data-test-service-requests-detail__creator-title-link]') ||
      pane.querySelector('[data-test-service-requests-detail__creator-name]');
    const name = text(nameEl);

    // Public LinkedIn URL — the canonical `/in/…` identity.
    const urlEl = pane.querySelector('[data-test-service-requests-detail__creator-title-link]')
                || pane.querySelector('[data-test-service-requests-detail__creator-profile-image-link]');
    let publicURL = "";
    if (urlEl) {
      // Strip query strings — LinkedIn appends tracking params we
      // don't need in the canonical identity.
      publicURL = (urlEl.href || "").split("?")[0];
    }

    // Headline / subtitle — the prospect's profile tagline.
    const headlineEl =
      pane.querySelector('[data-test-service-requests-detail__creator-subtitle] [aria-hidden="true"]') ||
      pane.querySelector('[data-test-service-requests-detail__creator-subtitle]');
    const headline = text(headlineEl);

    const locationEl = pane.querySelector('[data-test-service-requests-detail__location]');
    const location = text(locationEl);

    // Service requested — the project type heading at the top of
    // the detail pane (e.g. "Resume Review"). Same nested-span
    // shape as the list-item title.
    const serviceEl =
      pane.querySelector('[data-test-service-requests-detail__project-title] [aria-hidden="true"]') ||
      pane.querySelector('[data-test-service-requests-detail__project-title]');
    const service = text(serviceEl);

    // Questionnaire Q&A pairs — the actual request body. LinkedIn
    // emits parallel `__description-question="N"` / answer="N"`
    // pairs. Match by index so a missing one doesn't shift the
    // others.
    const questions = pane.querySelectorAll('[data-test-service-requests-detail__description-question]');
    const answers = pane.querySelectorAll('[data-test-service-requests-detail__description-answer]');
    const qaPairs = [];
    const pairCount = Math.min(questions.length, answers.length);
    for (let i = 0; i < pairCount; i += 1) {
      const q = text(questions[i]);
      const a = text(answers[i]);
      if (q && a) qaPairs.push(`${q}\n${a}`);
    }
    const projectDetails = qaPairs.join("\n\n");

    return { name, publicURL, headline, location, service, projectDetails };
  }

  /// Click the card and poll until the detail pane updates to
  /// match it (or a 2s deadline elapses). Returns whatever the
  /// detail pane shows at that point — caller decides whether to
  /// trust it.
  async function clickAndScrapeMarketplaceCard(card) {
    const expectedNameEl =
      card.querySelector('[data-test-service-requests-list-item__creator-name] [aria-hidden="true"]') ||
      card.querySelector('[data-test-service-requests-list-item__creator-name]');
    const expectedName = text(expectedNameEl).toLowerCase();

    card.click();

    const deadline = Date.now() + 2000;
    let last = null;
    while (Date.now() < deadline) {
      await new Promise((r) => setTimeout(r, 60));
      last = extractMarketplaceDetail();
      if (last && last.name && last.name.toLowerCase() === expectedName) {
        return last;
      }
    }
    log("clickAndScrapeMarketplaceCard timed out for:", expectedName, "got:", last && last.name);
    return last;
  }

  /// Compose a payload-shaped Profile object from a successful
  /// detail-pane scrape, falling back to whatever the row showed
  /// when the detail is missing or doesn't match.
  function buildMarketplaceProfileFromDetail(card, detail) {
    const rowFallback = extractMarketplaceProfile(card);
    if (!detail || !detail.name) return rowFallback;

    const cleanedName = cleanProfileName(detail.name);
    const parts = cleanedName.split(/\s+/).filter(Boolean);
    const firstName = parts[0] || rowFallback.firstName;
    const lastName = parts.slice(1).join(" ") || rowFallback.lastName;

    return {
      origin: SURFACE,
      firstName,
      lastName,
      linkedInURL: detail.publicURL || "",
      headline: detail.headline || "",
      title: null,
      company: null,
      location: detail.location || null,
      industry: null,
      about: null,
      tenure: null,
      publicLinkedInURL: detail.publicURL || null,
      salesNavURL: null,
      serviceRequested: detail.service || rowFallback.serviceRequested,
      projectDetails: detail.projectDetails || null
    };
  }

  // ---------------- selection storage ----------------

  /// Stable dedupe key for a profile across captures. Prefers
  /// the public LinkedIn URL when available; falls back to a
  /// synthetic `marketplace:NAME|SERVICE` key for Marketplace
  /// requests that didn't expose a profile link (the case where
  /// the requester's name is rendered as text without an
  /// anchor). Empty when neither identity signal is present —
  /// callers treat that as "uncapturable."
  function dedupeKey(profile) {
    if (profile && profile.linkedInURL) {
      return profile.linkedInURL.toLowerCase();
    }
    const name = `${(profile && profile.firstName) || ""} ${(profile && profile.lastName) || ""}`
      .trim()
      .toLowerCase();
    const service = ((profile && profile.serviceRequested) || "").toLowerCase();
    if (!name) return "";
    return service ? `marketplace:${name}|${service}` : `name:${name}`;
  }

  async function getSelections() {
    const res = await browser.storage.local.get("selections");
    return res.selections || [];
  }

  async function setSelections(list) {
    // Match popup.js — `.remove()` for empty queues. Safari's
    // storage API silently no-ops on some `set({key: []})`
    // calls; routing through `.remove()` keeps the per-card
    // pill flip reliable when the user clears via the popup.
    try {
      if (!Array.isArray(list) || list.length === 0) {
        await browser.storage.local.remove("selections");
      } else {
        await browser.storage.local.set({ selections: list });
      }
    } catch (err) {
      console.error(LOG_PREFIX, "setSelections failed:", err);
    }
  }

  async function addSelection(profile) {
    const key = dedupeKey(profile);
    if (!key) return;
    const sels = await getSelections();
    if (sels.some(p => dedupeKey(p) === key)) return;
    sels.push(profile);
    await setSelections(sels);
  }

  /// Add OR upgrade in place. Used by the Marketplace detail-pane
  /// flow: a lightweight name+service capture from an earlier
  /// session should be replaced with the richer detail-scraped
  /// version when the user clicks through. Match by dedupeKey —
  /// when the new profile has a URL and the old one didn't, both
  /// resolve to the same `marketplace:NAME|SERVICE` key, so the
  /// upgrade lands on the right row.
  async function upsertSelection(profile) {
    const key = dedupeKey(profile);
    if (!key) return;
    const sels = await getSelections();
    const idx = sels.findIndex(p => dedupeKey(p) === key);
    if (idx >= 0) {
      sels[idx] = profile;
    } else {
      sels.push(profile);
    }
    await setSelections(sels);
  }

  async function removeSelection(profile) {
    const key = typeof profile === "string"
      ? (profile || "").toLowerCase()
      : dedupeKey(profile);
    if (!key) return;
    const sels = await getSelections();
    const next = sels.filter(p => dedupeKey(p) !== key);
    await setSelections(next);
  }

  async function isSelected(profile) {
    const key = typeof profile === "string"
      ? (profile || "").toLowerCase()
      : dedupeKey(profile);
    if (!key) return false;
    const sels = await getSelections();
    return sels.some(p => dedupeKey(p) === key);
  }

  // ---------------- UI injection ----------------

  function makeButton(profile, card) {
    const wrap = document.createElement("button");
    wrap.type = "button";
    wrap.className = "amcrm-capture-btn";
    wrap.setAttribute("aria-label", "Capture this lead to AM Creative CRM");
    wrap.textContent = "+ Capture to CRM";
    wrap.addEventListener("click", async (e) => {
      e.preventDefault();
      e.stopPropagation();
      const selected = await isSelected(profile);
      if (selected) {
        await removeSelection(profile);
        wrap.textContent = "+ Capture to CRM";
        wrap.classList.remove("amcrm-capture-btn--on");
        return;
      }

      // Marketplace per-card capture: click the card so the
      // right-pane detail loads, scrape the questionnaire +
      // public URL, and store the enriched profile.
      if (SURFACE === "marketplace" && card) {
        wrap.disabled = true;
        wrap.textContent = "Capturing…";
        try {
          const detail = await clickAndScrapeMarketplaceCard(card);
          const richProfile = buildMarketplaceProfileFromDetail(card, detail);
          if (richProfile && dedupeKey(richProfile)) {
            await upsertSelection(richProfile);
            wrap.textContent = "✓ Captured";
            wrap.classList.add("amcrm-capture-btn--on");
          } else {
            wrap.textContent = "Failed";
            warn("Marketplace per-card capture failed — no dedupe key");
          }
        } finally {
          wrap.disabled = false;
        }
        return;
      }

      await addSelection(profile);
      wrap.textContent = "✓ Captured";
      wrap.classList.add("amcrm-capture-btn--on");
    });
    return wrap;
  }

  async function injectInto(card) {
    if (card.dataset.amcrmInjected === "1") return;
    if (card.dataset.amcrmSkipped === "1") return;
    const profile = extractProfile(card);
    // Need SOME identity signal — either a name or a URL — and
    // a non-empty dedupe key to qualify for capture. Without
    // those there's nothing to round-trip to the CRM. Marketplace
    // cards lacking a profile anchor still qualify if they have a
    // name + service combo (handled inside `dedupeKey`).
    if (!profile.firstName && !profile.lastName && !profile.linkedInURL) {
      card.dataset.amcrmSkipped = "1";
      warn("Skipped card — no name and no URL:", card);
      return;
    }
    if (!dedupeKey(profile)) {
      card.dataset.amcrmSkipped = "1";
      warn("Skipped card — no usable dedupe key (need name OR URL):", card);
      return;
    }
    card.dataset.amcrmInjected = "1";

    const btn = makeButton(profile, card);
    // Reflect existing selection state on injection so navigating
    // back to a search page after marking some rows shows the
    // checkmark instead of resetting.
    if (await isSelected(profile)) {
      btn.textContent = "✓ Captured";
      btn.classList.add("amcrm-capture-btn--on");
    }
    // Ensure the card can host an absolutely-positioned child.
    const cs = getComputedStyle(card);
    if (cs.position === "static") {
      card.style.position = "relative";
    }
    card.appendChild(btn);
  }

  function scan() {
    const cards = getCards();
    cards.forEach(injectInto);
    updateFloatingButton(cards);
  }

  // ---------------- floating "capture all" action ----------------

  /// A single page-level action button that captures every
  /// currently-visible card in one click. Lives at the bottom-
  /// right of the viewport with a live count, so the user can
  /// see at a glance how much is queued.
  ///
  /// Strict scope: only acts on cards already rendered on the
  /// current page. Never paginates, never scrolls, never opens
  /// other tabs — same TOS posture as the per-card pills, just
  /// fewer clicks for the common "capture this whole results
  /// page" workflow.
  let floatingBtn = null;

  function ensureFloatingButton() {
    if (floatingBtn && document.body.contains(floatingBtn)) return floatingBtn;
    floatingBtn = document.createElement("button");
    floatingBtn.type = "button";
    floatingBtn.className = "amcrm-capture-all-btn";
    floatingBtn.setAttribute("aria-label", "Capture all visible leads to AM Creative CRM");
    floatingBtn.addEventListener("click", captureAllVisible);
    document.body.appendChild(floatingBtn);
    return floatingBtn;
  }

  async function updateFloatingButton(cards) {
    if (!cards || cards.length === 0) {
      if (floatingBtn) floatingBtn.style.display = "none";
      return;
    }
    const btn = ensureFloatingButton();
    btn.style.display = "";
    // Count three buckets:
    //   - capturable: cards that produced a non-empty dedupe key
    //   - alreadyIn:  capturable cards that are already in queue
    //   - remaining:  capturable − alreadyIn
    // The label distinguishes between "all of these are already
    // queued" (genuine "✓ All captured") and "none of these are
    // capturable" (extraction missed — surface as a warning
    // label rather than the misleading green checkmark).
    const sels = await getSelections();
    const capturedKeys = new Set(sels.map(dedupeKey).filter(Boolean));
    let capturable = 0;
    let alreadyIn = 0;
    for (const card of cards) {
      const profile = extractProfile(card);
      const key = dedupeKey(profile);
      if (!key) continue;
      capturable += 1;
      if (capturedKeys.has(key)) alreadyIn += 1;
    }
    const remaining = capturable - alreadyIn;
    if (capturable === 0) {
      // Cards visible, but extraction couldn't produce a single
      // dedupe key for any of them. Don't fake success — call it
      // out so the user knows to widen the selectors / report.
      btn.textContent = `⚠ ${cards.length} card(s) visible — none capturable`;
      btn.classList.remove("amcrm-capture-all-btn--done");
    } else if (remaining === 0) {
      btn.textContent = `✓ All ${capturable} captured`;
      btn.classList.add("amcrm-capture-all-btn--done");
    } else {
      btn.textContent = `+ Capture all visible (${remaining})`;
      btn.classList.remove("amcrm-capture-all-btn--done");
    }
  }

  /// Mark a card's per-card pill as captured. The pill DOM lives
  /// inside the `<li>` we're working with; reflecting state there
  /// keeps the visual feedback consistent between the per-card
  /// and capture-all flows.
  function markCardPillCaptured(card) {
    const pill = card.querySelector(".amcrm-capture-btn");
    if (pill) {
      pill.textContent = "✓ Captured";
      pill.classList.add("amcrm-capture-btn--on");
    }
  }

  /// Marketplace bulk capture: walks each list `<li>`, clicks it
  /// to populate the right-pane detail view, scrapes the
  /// questionnaire body + profile URL, then moves on. Restores
  /// the originally-selected card at the end so the user lands
  /// back where they started.
  async function captureAllMarketplaceWithDetails(cards) {
    if (!cards || cards.length === 0) return;
    const originallySelected = document.querySelector(
      "li[role='tab'][aria-selected='true']"
    );

    let added = 0;
    let upgraded = 0;
    let skipped = 0;
    const btn = floatingBtn; // already ensured by updateFloatingButton

    for (let i = 0; i < cards.length; i += 1) {
      const card = cards[i];
      if (btn) btn.textContent = `Capturing ${i + 1} of ${cards.length}…`;

      let detail = null;
      try {
        detail = await clickAndScrapeMarketplaceCard(card);
      } catch (err) {
        warn("Detail scrape threw for card", i, err);
      }
      const profile = buildMarketplaceProfileFromDetail(card, detail);
      if (!profile || !dedupeKey(profile)) { skipped += 1; continue; }

      const sels = await getSelections();
      const key = dedupeKey(profile);
      const existing = sels.findIndex(p => dedupeKey(p) === key);
      if (existing >= 0) {
        upgraded += 1;
      } else {
        added += 1;
      }
      await upsertSelection(profile);
      markCardPillCaptured(card);
    }

    // Land the user back on the card they were originally viewing
    // so capture-all doesn't yank them to the last item in the
    // list mid-review.
    if (originallySelected && document.body.contains(originallySelected)) {
      originallySelected.click();
    }

    log(`Marketplace capture-all: added ${added}, upgraded ${upgraded}, skipped ${skipped}, total ${cards.length}.`);
    await updateFloatingButton(cards);
  }

  async function captureAllVisible() {
    const cards = getCards();
    if (SURFACE === "marketplace") {
      await captureAllMarketplaceWithDetails(cards);
      return;
    }
    let added = 0;
    let skippedNoKey = 0;
    for (const card of cards) {
      const profile = extractProfile(card);
      const key = dedupeKey(profile);
      if (!key) { skippedNoKey += 1; continue; }
      if (await isSelected(profile)) continue;
      await addSelection(profile);
      added += 1;
      markCardPillCaptured(card);
    }
    log(`Capture-all: added ${added}, skipped (no dedupe key) ${skippedNoKey}, total cards ${cards.length}.`);
    await updateFloatingButton(cards);
  }

  // Initial pass + observe DOM changes so cards added by
  // pagination / infinite scroll also get the button. Throttled
  // so a busy page doesn't trigger a scan storm.
  let scanTimer = null;
  function scheduleScan() {
    if (scanTimer) return;
    scanTimer = setTimeout(() => { scanTimer = null; scan(); }, 250);
  }

  // Per-card init is a Sales Nav / Marketplace concern only.
  // Public profile pages (`/in/...`) carry no result-list cards
  // and only get this content script so the PDF auto-walker can
  // run there; injecting the floating Capture button or running
  // the MutationObserver on a heavy profile page would just churn
  // for nothing.
  if (!onProfilePage) {
    scan();
    const observer = new MutationObserver(scheduleScan);
    observer.observe(document.body, { childList: true, subtree: true });
  }

  // Expose a quick diagnostic so you can paste
  // `window.__amcrm.debug()` in Safari's Console and see what
  // the script can / can't find on the page.
  window.__amcrm = {
    debug() {
      const cards = getCards();
      const summary = cards.slice(0, 5).map((c, i) => {
        const p = extractProfile(c);
        return `${i + 1}. ${p.firstName} ${p.lastName} — ${p.linkedInURL || "(no link)"} — ${p.headline || "(no headline)"}`;
      });
      // Count shadow roots + iframes to surface render
      // strategies the content script may need to chase.
      let shadowRoots = 0;
      for (const el of document.querySelectorAll("*")) {
        if (el.shadowRoot) shadowRoots += 1;
      }
      return {
        url: location.href,
        cardsFound: cards.length,
        sample: summary,
        knownSelectors: CARD_SELECTORS,
        iframesOnPage: document.querySelectorAll("iframe").length,
        openShadowRootsOnPage: shadowRoots,
        topLevelLinkSample: queryDeep(
          'a[href*="/sales/lead/"], a[href*="/sales/people/"], a[href*="/in/"]'
        ).slice(0, 5).map(a => a.href)
      };
    },
    rescan() { scan(); }
  };
  log("Ready. Run `window.__amcrm.debug()` in this console to inspect detection.");
})();
