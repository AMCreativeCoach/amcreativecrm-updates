// Messenger reply capture — runs ONLY on linkedin.com/messaging/*.
//
// Passive, read-only scrape of the conversation inbox: for each row we read
// the participant name, the last-message snippet, and the timestamp. If the
// snippet starts with "You:" the last message was Adam's (outbound) — skipped;
// otherwise the lead messaged last, so it's a reply worth capturing.
//
// This is deliberately a SEPARATE content script from content.js: reading the
// messenger must never pull in the Sales Nav walker / card-detection / compose
// code (the send path is the no-fly zone — see feedback_linkedin_send). This
// file clicks nothing and types nothing.
//
// The popup sends {type:"capture-replies"}; we return {ok, replies:[…]} and the
// popup base64-encodes them into amcreativecrm://linkedin-replies?data=… for
// LinkedInReplyIngester on the app side.
(() => {
  "use strict";

  function isVisible(el) {
    return el instanceof HTMLElement
      && el.offsetParent !== null
      && el.getBoundingClientRect().width > 0;
  }

  const MONTHS = {
    jan: 0, feb: 1, mar: 2, apr: 3, may: 4, jun: 5,
    jul: 6, aug: 7, sep: 8, oct: 9, nov: 10, dec: 11
  };

  // LinkedIn's inbox shows a bare "10:36 PM" (today) or "Jun 30" (this year) —
  // no machine timestamp. Reconstruct an approximate ISO here in the browser
  // (which knows "today" + locale); the app falls back to capture-time when
  // this returns null (day-names like "Mon", "Yesterday").
  function approximateISO(text) {
    if (!text) return null;
    const t = text.trim();
    const now = new Date();
    let m = t.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
    if (m) {
      let h = parseInt(m[1], 10) % 12;
      if (/pm/i.test(m[3])) h += 12;
      const d = new Date(now.getFullYear(), now.getMonth(), now.getDate(), h, parseInt(m[2], 10));
      return d.toISOString();
    }
    m = t.match(/^([A-Za-z]{3,})\s+(\d{1,2})$/);
    if (m) {
      const mo = MONTHS[m[1].toLowerCase().slice(0, 3)];
      if (mo != null) {
        let d = new Date(now.getFullYear(), mo, parseInt(m[2], 10), 12, 0);
        if (d.getTime() > now.getTime()) {
          d = new Date(now.getFullYear() - 1, mo, parseInt(m[2], 10), 12, 0);
        }
        return d.toISOString();
      }
    }
    return null;
  }

  function scrapeReplies() {
    const rows = document.querySelectorAll(
      "li.msg-conversation-listitem, .msg-conversation-listitem"
    );
    const out = [];
    const seen = new Set();
    rows.forEach(row => {
      if (!isVisible(row)) return;
      const nameEl = row.querySelector(".msg-conversation-listitem__participant-names");
      const name = nameEl ? nameEl.textContent.trim() : "";
      if (!name) return;

      const timeEl = row.querySelector(".msg-conversation-listitem__time-stamp");
      const timeText = timeEl ? timeEl.textContent.trim() : "";

      let snippet = "";
      const snippetEl = row.querySelector('[class*="message-snippet"]');
      if (snippetEl) {
        snippet = snippetEl.textContent.trim();
      } else {
        // Fallback: derive from the row text minus the name + repeated
        // timestamp + the "Via <page>" label LinkedIn sometimes prepends.
        let t = (row.innerText || "").replace(/\s+/g, " ").trim();
        if (name && t.startsWith(name)) t = t.slice(name.length).trim();
        if (timeText) t = t.split(timeText).join(" ").replace(/\s+/g, " ").trim();
        t = t.replace(/^Via\s+[A-Za-z ]+?\s(?=[A-Z])/, "").trim();
        snippet = t;
      }
      if (!snippet) return;

      // "You: …" (or "You …") = we sent the last message → not a pending reply.
      const low = snippet.toLowerCase();
      if (low.startsWith("you:") || low.startsWith("you ")) return;

      const key = name + "|" + snippet;
      if (seen.has(key)) return;
      seen.add(key);
      out.push({
        name,
        text: snippet,
        sentAtISO: approximateISO(timeText),
        sentAtText: timeText,
        profileURL: null
      });
    });
    return out;
  }

  browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message && message.type === "capture-replies") {
      try {
        const replies = scrapeReplies();
        console.log(`[AMCRM messenger] scraped ${replies.length} reply(ies)`);
        sendResponse({ ok: true, replies });
      } catch (err) {
        console.error("[AMCRM messenger] scrape failed:", err);
        sendResponse({ ok: false, error: String(err && err.message || err) });
      }
      return true; // async-safe response
    }
  });
})();
