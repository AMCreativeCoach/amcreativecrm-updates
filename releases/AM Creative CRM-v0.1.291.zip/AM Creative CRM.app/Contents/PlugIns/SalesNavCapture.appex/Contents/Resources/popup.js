// Toolbar popup for the Sales Nav Capture extension.
//
// Reads the accumulated selections from browser.storage.local,
// renders a list, and on "Send to CRM" tap builds a versioned JSON
// payload, base64-encodes it, and opens
// `amcreativecrm://import?data=<b64>` — which the macOS host app's
// `.onOpenURL` handler decodes into the SalesNavImportSheet for
// user confirmation. Selections are cleared after sending.

const PAYLOAD_VERSION = 1;

const els = {
  list: document.getElementById("list"),
  empty: document.getElementById("empty"),
  clear: document.getElementById("clear"),
  download: document.getElementById("download"),
  send: document.getElementById("send"),
  useScreenshots: document.getElementById("use-screenshots"),
  capture: document.getElementById("capture"),
  captureHint: document.getElementById("capture-hint"),
  captureReplies: document.getElementById("capture-replies"),
  repliesHint: document.getElementById("replies-hint")
};

/// Storage key for the persisted "Use screenshots instead of
/// PDFs" toggle. Read at queue-install time to stamp the active
/// queue's capture mode so the walker knows which path to take.
const STORAGE_USE_SCREENSHOTS = "amcrm_walker_use_screenshots";

// Walker queue schema — must match what the macOS launcher
// (`SalesNavPDFAutoDownloadLauncher`) emits and what `content.js`'s
// WALKER block decodes. Keep these field names stable; renaming
// one without updating both sides silently breaks the loop.
const WALKER_QUEUE_VERSION = 1;

/// Pulls the URN (LinkedIn's encrypted member identifier) out of
/// a Sales Nav lead URL. Sales Nav URLs look like
/// `https://www.linkedin.com/sales/lead/ACwAAAKC...,NAME_SEARCH,xxxx`
/// and the URN is everything between `/sales/lead/` and the first
/// comma / slash / query separator. Returns null when the input
/// isn't a Sales Nav URL.
///
/// **Why this matters.** LinkedIn redirects `/in/{URN}` URLs to
/// the canonical `/in/{slug}` profile server-side. So pointing
/// the walker at `/in/{URN}` works even when the lead is out of
/// the user's network — the Sales Nav lead page would otherwise
/// show "Unlock full profile" and trap the walker, but the public
/// profile URL doesn't have that problem.
function extractSalesNavURN(url) {
  if (!url) return null;
  const match = String(url).match(/\/sales\/lead\/([A-Za-z0-9_-]+)/i);
  return match ? match[1] : null;
}

/// Builds the `/in/{URN}` URL LinkedIn redirects to the canonical
/// public profile. Returns null when the input doesn't carry a
/// usable Sales Nav URN.
function publicURLFromSalesNav(salesNavURL) {
  const urn = extractSalesNavURN(salesNavURL);
  return urn ? `https://www.linkedin.com/in/${urn}` : null;
}

/// Resolves the most useful URL we have for a captured selection,
/// in the same preference order the macOS launcher uses: the
/// captured `publicLinkedInURL` first (direct path), then the
/// catch-all `linkedInURL` if it's already a public URL, then —
/// **new** — a URN-derived `/in/{URN}` URL synthesized from a
/// Sales Nav `/sales/lead/{URN}` URL when no public URL was
/// captured. The synthesized URL works because LinkedIn redirects
/// URN-based `/in/` paths to the canonical profile slug, so the
/// walker lands on the right public profile page and Save-to-PDF
/// runs as normal. Returns null for selections with no walkable
/// URL at all (synthetic `marketplace:NAME|SERVICE` dedupe keys
/// land here).
function pdfTargetURL(selection) {
  const pub = String(selection.publicLinkedInURL || "").trim();
  if (pub.toLowerCase().includes("linkedin.com/in/")) return pub;
  const main = String(selection.linkedInURL || "").trim();
  if (main.toLowerCase().includes("linkedin.com/in/")) return main;
  // Synthesize /in/{URN} from any Sales Nav URL we have. This
  // is the v0.1.75 fix for the "Unlock full profile" page the
  // selector-based redirect couldn't escape from.
  const sales = String(selection.salesNavURL || "").trim();
  const synthesized = publicURLFromSalesNav(sales) || publicURLFromSalesNav(main);
  if (synthesized) return synthesized;
  // Last resort — pass through the raw Sales Nav URL and let the
  // walker's anchor-scrape fallback handle it. Shouldn't fire in
  // practice unless the URN regex misses for some new URL shape.
  if (sales.toLowerCase().includes("linkedin.com/sales/lead/")) return sales;
  if (main.toLowerCase().includes("linkedin.com/sales/lead/")) return main;
  return null;
}

/// Maps a popup selection into the queue-item shape the walker
/// expects. Returns null for selections the walker can't act on
/// (no usable URL — caller filters those out before queueing).
function buildQueueItem(selection) {
  const target = pdfTargetURL(selection);
  if (!target) return null;
  const isPublic = target.toLowerCase().includes("/in/");
  // Always preserve the raw Sales Nav URL as a fallback when we
  // have it — it's where the messaging composer would open for
  // out-of-network leads (handled by a later phase of the Sales
  // Nav channel work).
  const rawSalesNav = String(
    selection.salesNavURL ||
    (String(selection.linkedInURL || "").toLowerCase().includes("/sales/lead/") ? selection.linkedInURL : "")
  ).trim();
  const name = `${selection.firstName || ""} ${selection.lastName || ""}`.trim();
  return {
    // leadID is meaningful only when the CRM hands us the queue —
    // popup-triggered runs haven't created Lead rows yet, so it
    // stays empty. The walker ignores it.
    leadID: "",
    name: name || "(unknown)",
    publicURL: isPublic ? target : "",
    salesNavURL: rawSalesNav
  };
}

function escape(s) {
  const div = document.createElement("div");
  div.textContent = s ?? "";
  return div.innerHTML;
}

async function getSelections() {
  const res = await browser.storage.local.get("selections");
  return Array.isArray(res.selections) ? res.selections : [];
}

async function setSelections(list) {
  // Use `.remove()` for an empty queue instead of
  // `.set({ selections: [] })`. Safari's storage API has been
  // observed to no-op silently when writing an empty array
  // (a popup `Clear` would appear to do nothing, even though
  // the JS executed). Removing the key entirely is reliable
  // and `getSelections` already treats a missing key as `[]`.
  try {
    if (!Array.isArray(list) || list.length === 0) {
      await browser.storage.local.remove("selections");
    } else {
      await browser.storage.local.set({ selections: list });
    }
  } catch (err) {
    console.error("[AMCRM popup] setSelections failed:", err);
  }
}

async function render() {
  const selections = await getSelections();
  if (selections.length === 0) {
    els.empty.hidden = false;
    els.list.innerHTML = "";
    els.send.disabled = true;
    els.send.textContent = "Send to CRM";
    els.clear.disabled = true;
    if (els.download) {
      els.download.disabled = true;
      els.download.textContent = "Download PDFs";
    }
    return;
  }
  els.empty.hidden = true;
  els.list.innerHTML = selections.map((p, i) => `
    <li class="row" data-idx="${i}">
      <div class="row__body">
        <div class="row__name">${escape(`${p.firstName || ""} ${p.lastName || ""}`.trim())}</div>
        ${p.headline ? `<div class="row__headline">${escape(p.headline)}</div>` : ""}
        ${p.location ? `<div class="row__location">${escape(p.location)}</div>` : ""}
      </div>
      <button type="button" class="row__remove" data-idx="${i}" aria-label="Remove">×</button>
    </li>
  `).join("");
  els.send.disabled = false;
  els.send.textContent = `Send ${selections.length} to CRM`;
  els.clear.disabled = false;

  // Download button reflects ONLY the selections that carry a
  // walker-usable URL (public `/in/{slug}` or Sales Nav
  // `/sales/lead/...`). Marketplace captures without a public
  // URL drop out — the walker has nothing to navigate to for
  // them, so silently including them in the queue would surface
  // as per-item failures later. Showing the count up front lets
  // the user see at a glance which captures will actually run.
  // Label flips between PDFs / Screenshots depending on the
  // settings toggle so it's obvious what the click will do.
  if (els.download) {
    const eligibleCount = selections.filter(s => pdfTargetURL(s) !== null).length;
    const useScreenshots = els.useScreenshots && els.useScreenshots.checked;
    const noun = useScreenshots ? "Screenshot" : "PDF";
    if (eligibleCount === 0) {
      els.download.disabled = true;
      els.download.textContent = `Download ${noun}s`;
    } else {
      els.download.disabled = false;
      els.download.textContent = `Download ${eligibleCount} ${noun}${eligibleCount === 1 ? "" : "s"}`;
    }
  }

  els.list.querySelectorAll(".row__remove").forEach(btn => {
    btn.addEventListener("click", async (e) => {
      // Defensive: stop the click from bubbling to the row
      // (some Safari builds dispatch a row-level activate event
      // before the button receives its own click in popup
      // contexts).
      e.preventDefault();
      e.stopPropagation();
      const idx = parseInt(e.currentTarget.dataset.idx, 10);
      // Re-read from storage rather than relying on the
      // closure-captured `selections`. Two close clicks can
      // arrive faster than the previous render() finishes, and
      // the stored state is the source of truth.
      const current = await getSelections();
      const next = current.filter((_, i) => i !== idx);
      console.log("[AMCRM popup] Remove idx", idx, "→", next.length, "remaining");
      await setSelections(next);
      await render();
    });
  });
}

els.clear.addEventListener("click", async () => {
  console.log("[AMCRM popup] Clear all selections");
  await setSelections([]);
  await render();
});

if (els.download) {
  els.download.addEventListener("click", async () => {
    const selections = await getSelections();
    const items = selections.map(buildQueueItem).filter(Boolean);
    if (items.length === 0) return;

    // **Direct storage write, no `?amcrm_queue=` URL bootstrap.**
    // The earlier version base64-encoded the queue into a
    // `?amcrm_queue=<b64>` query param on the first lead's URL,
    // which works fine for small batches but breaks at scale —
    // ~93 leads of typical Sales Nav URL length encoded past
    // LinkedIn's 16KB HTTP request-line limit and returned a
    // `Bad Request — An HTTP line is larger than 16384 bytes`
    // from their stack. Writing the queue straight to
    // `browser.storage.local` under the same keys the walker's
    // `readState()` reads from sidesteps the URL budget entirely
    // — the tab can land at the plain lead URL and the content
    // script will pick up the queue from storage on first tick.
    //
    // Keep the storage keys in sync with content.js's WALKER
    // constants (STORAGE_QUEUE, STORAGE_CURSOR, STORAGE_NEXT_AT,
    // STORAGE_RESULTS, STORAGE_STATUS_MSG). The macOS launcher
    // uses the URL-bootstrap path because it can't write to
    // extension storage from outside the browser — that path
    // is now capped to ~30 leads to stay under the URL limit.
    // Pick the capture mode from the popup's toggle and stamp
    // it on the queue. The walker reads `amcrm_walker_capture_mode`
    // at tick time and branches between Save-to-PDF and the
    // scroll-stitch screenshot path.
    const useScreenshots = els.useScreenshots && els.useScreenshots.checked;
    await browser.storage.local.set({
      "amcrm_walker_queue": items,
      "amcrm_walker_cursor": 0,
      "amcrm_walker_next_at": 0,
      "amcrm_walker_results": [],
      "amcrm_walker_status": `Queue installed: ${items.length} lead(s).`,
      "amcrm_walker_capture_mode": useScreenshots ? "screenshot" : "pdf",
      "amcrm_walker_last_saved_path": "",
      // Explicit "session active" signal. The walker's tick() now
      // gates on this flag — without it set, the walker no-ops on
      // every page load. Sending Follow-up from the CRM no longer
      // wakes the walker, even with a stale queue in storage.
      "amcrm_walker_session_active": true
    });

    const first = items[0];
    const dest = first.publicURL || first.salesNavURL;
    if (!dest) return;
    console.log(`[AMCRM popup] Wrote ${items.length}-lead queue to storage; opening ${dest}`);
    await browser.tabs.create({ url: dest });
    // Intentionally NOT clearing selections — the user may still
    // want to "Send to CRM" after the walker run finishes, and a
    // surprise wipe of the captured list would feel hostile.
    // They can use Clear explicitly when they're done.
    window.close();
  });
}

els.send.addEventListener("click", async () => {
  const selections = await getSelections();
  if (selections.length === 0) return;

  const payload = {
    version: PAYLOAD_VERSION,
    capturedAt: new Date().toISOString(),
    leads: selections
  };
  const json = JSON.stringify(payload);
  // btoa can't handle UTF-8 directly — round-trip through the
  // unescape(encodeURIComponent(...)) idiom so non-ASCII names
  // (which exist in any real lead list) survive the encode.
  const b64 = btoa(unescape(encodeURIComponent(json)));
  const url = `amcreativecrm://import?data=${encodeURIComponent(b64)}`;

  // Hand the URL to Safari — the macOS scheme handler picks it up
  // and the host CRM's `.onOpenURL` fires. browser.tabs.create
  // is the cross-extension-API way to open a URL from the popup;
  // Safari recognizes the custom scheme and routes accordingly.
  await browser.tabs.create({ url });

  // Clear the queue once the payload has been handed off — the
  // CRM's confirmation sheet is now the source of truth for
  // what actually gets imported.
  await setSelections([]);
  window.close();
});

/// Persist the "Use screenshots" toggle so it survives popup
/// reopens. Re-renders so the Download button label flips
/// between PDFs / Screenshots immediately.
async function loadUseScreenshotsPreference() {
  if (!els.useScreenshots) return;
  const res = await browser.storage.local.get(STORAGE_USE_SCREENSHOTS);
  els.useScreenshots.checked = res[STORAGE_USE_SCREENSHOTS] === true;
}

if (els.useScreenshots) {
  els.useScreenshots.addEventListener("change", async () => {
    await browser.storage.local.set({
      [STORAGE_USE_SCREENSHOTS]: els.useScreenshots.checked
    });
    await render();
  });
}

/// Inspects the active tab and enables the "Capture this profile"
/// button only when it's on a LinkedIn `/in/` profile page. Sales
/// Nav lead pages and arbitrary LinkedIn URLs aren't supported
/// here — scroll-stitch needs the content script to be running
/// in the page, and it only matches `linkedin.com/sales/*`,
/// `/service-marketplace/*`, and `/in/*`. Profile capture is
/// scoped to `/in/*` because that's the canonical resume-style
/// public view.
async function updateCaptureButton() {
  if (!els.capture || !els.captureHint) return;
  try {
    const tabs = await browser.tabs.query({ active: true, currentWindow: true });
    const activeTab = tabs && tabs[0];
    if (!activeTab || !activeTab.url) {
      els.capture.disabled = true;
      els.captureHint.textContent = "Open a LinkedIn profile in the current tab to enable.";
      return;
    }
    const url = activeTab.url.toLowerCase();
    if (url.includes("linkedin.com/in/")) {
      els.capture.disabled = false;
      els.captureHint.textContent = "Captures the current LinkedIn profile end-to-end. Saves to ~/Downloads as PNG.";
    } else {
      els.capture.disabled = true;
      els.captureHint.textContent = "Open a LinkedIn profile in the current tab to enable.";
    }
  } catch (err) {
    console.error("[AMCRM popup] active-tab query failed:", err);
    els.capture.disabled = true;
    els.captureHint.textContent = "Couldn't read the active tab.";
  }
}

if (els.capture) {
  els.capture.addEventListener("click", async () => {
    els.capture.disabled = true;
    els.capture.textContent = "Capturing…";
    els.captureHint.textContent = "Scrolling and stitching the page — this can take 10–30 seconds. Don't switch tabs.";
    try {
      const tabs = await browser.tabs.query({ active: true, currentWindow: true });
      const activeTab = tabs && tabs[0];
      if (!activeTab || !activeTab.id) {
        throw new Error("No active tab");
      }
      const response = await browser.tabs.sendMessage(activeTab.id, { type: "capture-profile" });
      if (!response || !response.ok) {
        throw new Error((response && response.error) || "capture-profile returned no response");
      }
      els.captureHint.textContent = `Saved: ${response.filename}`;
      els.capture.textContent = "Captured ✓";
    } catch (err) {
      console.error("[AMCRM popup] capture failed:", err);
      els.captureHint.textContent = `Capture failed: ${err.message || err}`;
      els.capture.textContent = "Capture this profile";
      els.capture.disabled = false;
    }
  });
}

/// Enables "Capture replies" only when the active tab is the LinkedIn
/// messaging inbox — that's where `messenger.js` is loaded and can scrape.
async function updateRepliesButton() {
  if (!els.captureReplies || !els.repliesHint) return;
  try {
    const tabs = await browser.tabs.query({ active: true, currentWindow: true });
    const activeTab = tabs && tabs[0];
    const url = (activeTab && activeTab.url || "").toLowerCase();
    if (url.includes("linkedin.com/messaging")) {
      els.captureReplies.disabled = false;
      els.repliesHint.textContent = "Reads new replies from your open inbox and logs them onto the matching leads.";
    } else {
      els.captureReplies.disabled = true;
      els.repliesHint.textContent = "Open your LinkedIn messaging inbox in the current tab to enable.";
    }
  } catch (err) {
    console.error("[AMCRM popup] replies active-tab query failed:", err);
    els.captureReplies.disabled = true;
  }
}

if (els.captureReplies) {
  els.captureReplies.addEventListener("click", async () => {
    els.captureReplies.disabled = true;
    els.captureReplies.textContent = "Capturing…";
    try {
      const tabs = await browser.tabs.query({ active: true, currentWindow: true });
      const activeTab = tabs && tabs[0];
      if (!activeTab || !activeTab.id) throw new Error("No active tab");
      const response = await browser.tabs.sendMessage(activeTab.id, { type: "capture-replies" });
      if (!response || !response.ok) {
        throw new Error((response && response.error) || "no response from messenger");
      }
      const replies = Array.isArray(response.replies) ? response.replies : [];
      if (replies.length === 0) {
        els.repliesHint.textContent = "No new replies found (everything you see is already answered).";
        els.captureReplies.textContent = "Capture replies";
        els.captureReplies.disabled = false;
        return;
      }
      // Same versioned-JSON → base64 → amcreativecrm:// transport as the
      // Sales Nav import. The app's LinkedInReplyPayload.decode reads it.
      const payload = { version: PAYLOAD_VERSION, replies };
      const b64 = btoa(unescape(encodeURIComponent(JSON.stringify(payload))));
      const url = `amcreativecrm://linkedin-replies?data=${encodeURIComponent(b64)}`;
      await browser.tabs.create({ url });
      els.repliesHint.textContent = `Sent ${replies.length} reply(ies) to the CRM.`;
      els.captureReplies.textContent = "Captured ✓";
    } catch (err) {
      console.error("[AMCRM popup] capture-replies failed:", err);
      els.repliesHint.textContent = `Capture failed: ${err.message || err}`;
      els.captureReplies.textContent = "Capture replies";
      els.captureReplies.disabled = false;
    }
  });
}

loadUseScreenshotsPreference().then(render);
updateCaptureButton();
updateRepliesButton();
